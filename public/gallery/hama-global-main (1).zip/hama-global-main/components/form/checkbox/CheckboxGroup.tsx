"use client";

import {
  CheckboxGroup as ChakraCheckboxGroup,
  Fieldset,
  Text,
} from "@chakra-ui/react";
import { CheckboxGroupProps } from "@/types";
import { Checkbox } from "./Checkbox";

export const CheckboxGroup = ({
  label,
  items,
  value,
  onChange,
}: CheckboxGroupProps) => {
  return (
    <Fieldset.Root>
      <ChakraCheckboxGroup value={value} onValueChange={onChange}>
        {label && (
          <Fieldset.Legend fontSize="sm" mb="2">
            {label}
          </Fieldset.Legend>
        )}

        <Fieldset.Content>
          {items.map(({ label, value }) => (
            <Checkbox key={value} value={value}>
              <Text variant="paragraphSmall">{label}</Text>
            </Checkbox>
          ))}
        </Fieldset.Content>
      </ChakraCheckboxGroup>
    </Fieldset.Root>
  );
};
