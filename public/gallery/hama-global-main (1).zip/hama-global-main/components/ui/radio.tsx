import { RadioGroup as ChakraRadioGroup } from "@chakra-ui/react";
import * as React from "react";

export interface RadioProps extends ChakraRadioGroup.ItemProps {
  rootRef?: React.Ref<HTMLDivElement>;
  inputProps?: React.InputHTMLAttributes<HTMLInputElement>;
}

export const Radio = React.forwardRef<HTMLInputElement, RadioProps>(
  function Radio(props, ref) {
    const { children, inputProps, rootRef, ...rest } = props;
    return (
      <ChakraRadioGroup.Item
        ref={rootRef}
        {...rest}
        display="flex"
        alignItems="center"
        gap={2}
      >
        <ChakraRadioGroup.ItemHiddenInput ref={ref} {...inputProps} />

        <ChakraRadioGroup.ItemIndicator
          boxSize="24px"
          borderRadius="full"
          border="2px solid"
          borderColor="green.500"
          bg="white"
          _checked={{
            bg: "green.500",
            borderColor: "green.500",
          }}
        />

        {children && (
          <ChakraRadioGroup.ItemText width="full">
            {children}
          </ChakraRadioGroup.ItemText>
        )}
      </ChakraRadioGroup.Item>
    );
  }
);

export const RadioGroup = ChakraRadioGroup.Root;
