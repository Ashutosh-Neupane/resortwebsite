"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { Box, Button, Heading, HStack, Text, VStack } from "@chakra-ui/react";

import { useConfigQuery, useUserProfileQuery } from "@/hooks/api";
import { ProductCardProps } from "@/types";
import { ROUTES } from "@/constants";
import { generateNextPath } from "@/utils";
import { VisibleSection } from "../visibleSection";

export const ProductCard: React.FC<ProductCardProps> = ({
  category,
  image,
  title,
  name,
  price,
  originalPrice,
  discount,
  hasAddToCart,
  stock_qty,
}) => {
  const router = useRouter();

  const { data: config } = useConfigQuery();
  const { data: userProfileData } = useUserProfileQuery();

  const isOutOfStock = stock_qty <= 0;

  return (
    <VStack
      alignItems="stretch"
      gap={{ base: "10px", md: "12px", lg: "14px" }}
      overflow="hidden"
      my={{ base: "16px", md: "18px", lg: "18px" }}
      padding={{ base: "16px", md: "18px", lg: "20px" }}
      bg="white"
      borderRadius="1rem"
      border="1px solid"
      borderColor="system.neutral.separator.light"
      transition="all 0.3s ease"
      _hover={{
        boxShadow: "lg",
        transform: "translateY(-4px)",
        // bg: "gray.50",
      }}
      cursor="pointer"
      onClick={() => {
        router.push(
          generateNextPath(ROUTES.APP.INDIVIDUAL_PRODUCT, {
            productName: title,
          })
        );
      }}
      position="relative"
    >
      {/* Out of stock badge */}
      {isOutOfStock && (
        <Box
          position="absolute"
          top="0"
          right="0"
          bg="red.500"
          color="white"
          px="2"
          py="1"
          fontSize="xs"
          fontWeight="bold"
          borderBottomLeftRadius="md"
          zIndex="10"
        >
          Out of Stock
        </Box>
      )}
      {/* Discount Ribbon */}
      {Number(discount) > 0 && userProfileData && !isOutOfStock && (
        <Box
          position="absolute"
          top=" -6px"
          right="-52px"
          width="162px"
          height="74px"
          bg="green.500"
          color="white"
          textAlign="center"
          lineHeight="1"
          fontSize="sm"
          fontWeight="bold"
          transform="rotate(45deg)"
          py={1}
          zIndex="1"
        >
          <HStack
            gap="0.6rem"
            align="center"
            position={"absolute"}
            top=" 2.4rem"
            dropShadow={"md"}
            right="3.4rem"
            rotate={"-45deg"}
          >
            <Box
              textShadow="9px 1px 3px #22c55e"
              css={{
                WebkitTextStrokeWidth: "3px",
                WebkitTextStrokeColor: "#22c55e",
              }}
              letterSpacing="-6px"
              fontSize="3.5rem"
            >
              {discount}
            </Box>
            <VStack gap="0">
              <Text>%</Text>
              <Text>OFF</Text>
            </VStack>
          </HStack>
        </Box>
      )}

      {/* Product Image */}
      <Box
        position="relative"
        w="full"
        pt="100%" // 1:1 ratio using padding trick
        overflow="hidden"
      >
        {/* Category Tag */}
        <VisibleSection visibility={config.category_visibility}>
          {category && (
            <Text
              fontSize={{ base: "xs", md: "xs" }}
              fontWeight="semibold"
              position={"absolute"}
              top={"0"}
              left={"0"}
              zIndex={20}
              border="1px solid"
              borderColor="system.neutral.separator.light"
              borderRadius="full"
              width="fit-content"
              color="system.text.light.light"
              bg="gray.100"
              px="10px"
              py="4px"
            >
              {category}
            </Text>
          )}
        </VisibleSection>
        <Image
          src={image || config.company_details_url}
          alt={title}
          fill
          style={{ objectFit: "contain", objectPosition: "center" }}
        />
      </Box>

      {/* Product Info */}
      <VStack align="start" gap="8px">
        {/* Title */}
        {/* <Heading
          variant="heading6"
          display="none"
          fontSize={{ base: "16px", md: "16px", lg: "18px" }}
          fontWeight="600"
          color="gray.800"
        >
          {title}
        </Heading> */}

        {/* Description */}
        <Box
          color="system.text.light.light"
          lineClamp={"2"}
          fontWeight={"bold"}
          fontSize={{ base: "sm", md: "md" }}
          minHeight={"45px"}
        >
          {name}
        </Box>

        {/* Price Section */}
        <HStack justify="space-between" w="full" pt="8px" align="flex-start">
          <HStack gap={1} align="baseline">
            <VisibleSection visibility={config?.rate_visibility}>
              {userProfileData && (
                <VStack gap={0} align="flex-start">
                  <Heading
                    variant={{ base: "heading6", md: "heading7" }}
                    fontSize={{ base: "sm", md: "md" }}
                    fontWeight="400"
                    color={"brand.700"}
                  >
                    {config.currency} {price}
                  </Heading>
                  {Number(discount) > 0 && (
                    <Text
                      fontSize={{ base: "sm", md: "md" }}
                      color={"red.400"}
                      textDecoration="line-through"
                    >
                      {config.currency} {originalPrice}
                    </Text>
                  )}
                </VStack>
              )}
            </VisibleSection>
            {/* {discount && Number(discount) > 0 && (
              <Text
                fontSize="lg"
                fontWeight="medium"
                color={isOutOfStock ? "gray.300" : "white"}
                bg={isOutOfStock ? "gray.100" : "green.700"}
                borderRadius="full"
                px="10px"
                py="2px"
              >
                -{discount}%
              </Text>
            )} */}
          </HStack>
        </HStack>

        {/* CTA */}
        {hasAddToCart && (
          <Box>
            <Button
              marginTop="8px"
              width="full"
              colorScheme="teal"
              variant={isOutOfStock ? "ghost" : "solid"}
              size="sm"
              borderRadius="md"
              cursor={isOutOfStock ? "not-allowed" : "pointer"}
              _hover={{
                bg: isOutOfStock ? undefined : "teal.600",
              }}
            >
              {isOutOfStock ? "Out of Stock" : "Add to Cart"}
            </Button>
          </Box>
        )}
      </VStack>
    </VStack>
  );
};
