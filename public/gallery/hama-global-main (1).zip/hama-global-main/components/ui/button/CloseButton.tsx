import * as React from "react";
import { LuX } from "react-icons/lu";
import type { ButtonProps } from "@chakra-ui/react";
import { IconButton as ChakraIconButton } from "@chakra-ui/react";

export const CloseButton = React.forwardRef<HTMLButtonElement, ButtonProps>(
  function CloseButton(props, ref) {
    return (
      <ChakraIconButton
        rounded={"full"}
        bg={"gray.200"}
        height={11}
        width={11}
        p={0}
        aria-label="Close"
        ref={ref}
        {...props}
      >
        {props.children ?? <LuX color="red" height={20} width={20} />}
      </ChakraIconButton>
    );
  }
);
