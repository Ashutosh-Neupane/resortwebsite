"use client";

import { useForm } from "react-hook-form";
import { VStack } from "@chakra-ui/react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";

import { Button, FormProvider, Header, PasswordInput } from "@/components";
import { useSetPasswordMutation } from "@/hooks/api";
import { setPasswordSchema } from "@/schema";
import { removeTokenFromClient } from "@/service";
import { useLayoutDialogStore } from "@/store";
import { SetPasswordProps, SetPasswordType } from "@/types";

// Default form values
const defaultValues: SetPasswordType = {
  password: "",
  confirmPassword: "",
};

export const SetPassword = ({ setActiveStep }: SetPasswordProps) => {
  const queryClient = useQueryClient();
  const methods = useForm<SetPasswordType>({
    resolver: zodResolver(setPasswordSchema),
    defaultValues,
  });

  const { mutate: setPassword, isPending } = useSetPasswordMutation();
  const { updateSignInOpen } = useLayoutDialogStore();

  const onSubmit = (data: SetPasswordType) => {
    setPassword(data, {
      onSuccess: () => {
        removeTokenFromClient();
        updateSignInOpen(true);
        setActiveStep(2);
        queryClient.resetQueries({ queryKey: ["user-profile"] });
      },
      onError: () => {
        // handle error if needed
      },
    });
  };

  return (
    <VStack
      align="stretch"
      justify="center"
      gap={5}
      h="full"
      px={{ base: "32px", xl: "80px" }}
      my="60px"
    >
      <Header
        title="Set Password"
        description="Please use the given credentials to begin transactions."
      />
      <FormProvider methods={methods} onSubmit={onSubmit}>
        <PasswordFormFields isPending={isPending} />
      </FormProvider>
    </VStack>
  );
};

// Separated form fields for better readability
const PasswordFormFields = ({ isPending }: { isPending: boolean }) => (
  <VStack align="stretch" gap={4} mt="20px">
    <PasswordInput name="password" label="Password" />
    <PasswordInput name="confirmPassword" label="Confirm Password" />
    <Button mt={2} type="submit" loading={isPending}>
      Submit
    </Button>
  </VStack>
);
