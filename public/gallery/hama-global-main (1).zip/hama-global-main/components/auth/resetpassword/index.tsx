"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

import { Dialog, LoginDialog } from "@/components";
import { useConfigQuery } from "@/hooks/api";
import { RegisterDialogProps } from "@/types";

import { SetPassword } from "./SetPassword";
import { AuthWrapper } from "../wrapper";
import { Box } from "@chakra-ui/react";
import { CloseCircleIcon } from "@/assets/svg";

// Animation variants for form transitions
const slideVariants = {
  initial: (direction: number) => ({
    x: direction > 0 ? "5%" : "-5%",
    opacity: 0,
  }),
  animate: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.2 },
  },
  exit: (direction: number) => ({
    x: direction > 0 ? "-5%" : "5%",
    opacity: 0,
    transition: { duration: 0.1 },
  }),
};

export const ResetPasswordDialog = ({
  open,
  onClose,
  initialStep = 1,
}: RegisterDialogProps) => {
  const [activeStep, setActiveStep] = useState(initialStep);
  const [direction, setDirection] = useState(1);
  const [isFirstRender, setIsFirstRender] = useState(true);

  const { data: imageData } = useConfigQuery();

  // Handle open state changes and reset step state
  useEffect(() => {
    if (open) {
      setActiveStep(initialStep);
      setIsFirstRender(initialStep === 1);
    }
  }, [open, initialStep]);

  // Close dialog and reset state
  const handleClose = () => {
    setActiveStep(1);
    setIsFirstRender(true);
    onClose();
  };

  // Navigate between steps and manage animation direction
  const moveToStep = (nextStep: number) => {
    setDirection(nextStep > activeStep ? 1 : -1);
    setActiveStep(nextStep);
  };

  // Dynamically render form content
  const renderFormStep = () => {
    switch (activeStep) {
      case 1:
        return <SetPassword setActiveStep={moveToStep} />;
      case 2:
        return <LoginDialog open onClose={onClose} />;
      default:
        return null;
    }
  };

  // Select background image based on step
  const getStepImage = () => {
    if (activeStep === 1) return imageData?.set_password_screen_photo_link;
    if (activeStep === 2) return imageData?.login_screen_photo_link;
    return "";
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      contentMinWidth={{ lg: "1000px", xl: "1200px" }}
    >
      <Box
        position="absolute"
        top="16px"
        right="16px"
        zIndex={3}
        cursor="pointer"
        onClick={handleClose}
      >
        <CloseCircleIcon color="red" />
      </Box>
      <AuthWrapper imageSrc={getStepImage()}>
        <AnimatePresence custom={direction} mode="wait">
          <motion.div
            key={activeStep}
            variants={
              isFirstRender && activeStep === 1 ? undefined : slideVariants
            }
            initial="initial"
            animate="animate"
            exit="exit"
            custom={direction}
          >
            {renderFormStep()}
          </motion.div>
        </AnimatePresence>
      </AuthWrapper>
    </Dialog>
  );
};
