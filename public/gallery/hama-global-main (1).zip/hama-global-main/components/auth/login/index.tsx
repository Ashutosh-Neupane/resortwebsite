"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { Box, HStack, IconButton, Text, VStack } from "@chakra-ui/react";
import { zodResolver } from "@hookform/resolvers/zod";

import {
  Button,
  Checkbox,
  Dialog,
  FormProvider,
  Header,
  OtpDialog,
  PasswordInput,
  TextFieldInput,
} from "@/components";
import {
  useLoginMutation,
  useConfigQuery,
  useUserProfileQuery,
} from "@/hooks/api";
import { LoginFormType, loginSchema } from "@/schema";
import { useLayoutDialogStore, useRegisterDialogStore } from "@/store";
import { LoginDialogProps } from "@/types";

import { AuthWrapper } from "../wrapper";
import { CloseCircleIcon } from "@/assets/svg";
import { ROUTES } from "@/constants";
import { useRouter } from "next/navigation";
import { SetPassword } from "./SetPassword";

const defaultValues = {
  email: "",
  password: "",
};

export const LoginDialog = ({ open, onClose }: LoginDialogProps) => {
  const router = useRouter();
  const [, setActiveStep] = useState(0);
  const [showSetPassword, setShowSetPassword] = useState(false);
  const methods = useForm<LoginFormType>({
    resolver: zodResolver(loginSchema),
    defaultValues,
  });

  const { mutateAsync: login, isPending } = useLoginMutation();
  const { refetch: refetchUserProfile } = useUserProfileQuery();

  const onSubmit = async (data: LoginFormType) => {
    try {
      await login(data);
      methods.reset();

      // Refetch fresh user profile data after login
      const { data: userProfileData } = await refetchUserProfile();

      if (userProfileData?.password_changed === 0) {
        onClose();
        setShowSetPassword(true);
      } else {
        onClose();
        router.push(ROUTES.APP.SHOP_NOW);
      }
    } catch {}
  };

  const { updateSignInOpen } = useLayoutDialogStore();
  const { updateSignUpOpen } = useRegisterDialogStore();

  const handleSignin = () => {
    updateSignUpOpen(true);
    updateSignInOpen(false);
  };
  const handleClose = () => {
    updateSignInOpen(false);
  };

  const [isOtpOpen, setOtpOpen] = useState(false);

  const handleForgotPassword = () => {
    onClose();
    setOtpOpen(true);
  };

  const { data: imageData } = useConfigQuery();
  const LoginImage = imageData?.login_screen_photo_link;

  return (
    <>
      <Dialog
        open={open && !showSetPassword}
        onClose={onClose}
        contentMinWidth={{
          lg: "1000px",
          xl: "1200px",
        }}
      >
        <Box
          position="absolute"
          top="16px"
          right="16px"
          zIndex={3}
          cursor="pointer"
          onClick={handleClose}
        >
          <CloseCircleIcon color="red" />
        </Box>
        <AuthWrapper imageSrc={LoginImage}>
          <VStack
            alignItems="stretch"
            justifyContent="center"
            gap="20px"
            height="full"
            px={{
              base: "32px",
              xl: "80px",
            }}
          >
            <Header
              title="Login Screen"
              description="Please provide the given credentials to login."
            />

            <FormProvider methods={methods} onSubmit={onSubmit}>
              <VStack alignItems="stretch" gap="16px" marginTop="20px">
                <TextFieldInput
                  name="email"
                  label="Email"
                  placeholder="Enter Email"
                />
                <PasswordInput name="password" label="Password" />

                <HStack justifyContent="space-between">
                  <Checkbox>Remember me</Checkbox>

                  <IconButton
                    variant={"plain"}
                    color="system.text.light.light"
                    as={"button"}
                    type="button"
                    _hover={{ cursor: "pointer" }}
                    onClick={handleForgotPassword}
                  >
                    Forgot password?
                  </IconButton>
                </HStack>

                <Button type="submit" marginTop="8px" loading={isPending}>
                  Submit
                </Button>
              </VStack>
            </FormProvider>

            <Text
              variant="subtitle2"
              bottom="32px"
              left="0"
              width="full"
              color="system.text.light.light"
              textAlign="center"
            >
              Don&apos;t have an account?{" "}
              <Text
                as="span"
                variant="paragraphSmall"
                color="system.neutral.info.light"
                cursor="pointer"
                onClick={handleSignin}
              >
                Sign up
              </Text>
            </Text>
          </VStack>
        </AuthWrapper>
      </Dialog>

      {showSetPassword && (
        <Dialog
          open={showSetPassword}
          onClose={() => setShowSetPassword(false)}
          contentMinWidth={{
            lg: "1000px",
            xl: "1200px",
          }}
        >
          <Box
            position="absolute"
            top="16px"
            right="16px"
            zIndex={3}
            cursor="pointer"
            onClick={() => setShowSetPassword(false)}
          >
            <CloseCircleIcon color="red" />
          </Box>
          <AuthWrapper imageSrc={LoginImage}>
            <SetPassword
              setActiveStep={setActiveStep}
              closeDialog={() => setShowSetPassword(false)}
            />
          </AuthWrapper>
        </Dialog>
      )}

      <OtpDialog open={isOtpOpen} onClose={() => setOtpOpen(false)} />
    </>
  );
};
