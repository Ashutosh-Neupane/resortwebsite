"use client";

import { useForm } from "react-hook-form";
import { VStack } from "@chakra-ui/react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";

import { Button, FormProvider, Header, PasswordInput } from "@/components";
import { useSetPasswordMutation } from "@/hooks/api";
import { setPasswordSchema } from "@/schema";
import { removeTokenFromClient } from "@/service";
import { useLayoutDialogStore } from "@/store";
import { SetPasswordProps, SetPasswordType } from "@/types";

const defaultValues: SetPasswordType = {
  password: "",
  confirmPassword: "",
};

export const SetPassword = ({
  setActiveStep,
  closeDialog,
}: SetPasswordProps & { closeDialog: () => void }) => {
  const queryClient = useQueryClient();

  const methods = useForm<SetPasswordType>({
    resolver: zodResolver(setPasswordSchema),
    defaultValues,
  });

  const { mutate: SetPassword, isPending } = useSetPasswordMutation();
  const { updateSignInOpen } = useLayoutDialogStore();

  const onSubmit = (data: SetPasswordType) => {
    SetPassword(data, {
      onSuccess: () => {
        removeTokenFromClient();
        updateSignInOpen(true);
        setActiveStep(4);
        queryClient.resetQueries({ queryKey: ["user-profile"] });
        closeDialog();
      },
      onError: () => {},
    });
  };

  return (
    <VStack
      alignItems="stretch"
      justifyContent="center"
      gap="20px"
      height="full"
      px="80px"
      mt={"60px"}
    >
      <Header
        title="Set Password"
        description="Create a strong password to protect your account"
      />

      <FormProvider methods={methods} onSubmit={onSubmit}>
        <VStack alignItems="stretch" gap="16px">
          <PasswordInput name="password" label="Password" />
          <PasswordInput name="confirmPassword" label="Confirm Password" />
          <Button marginTop="8px" type="submit" loading={isPending}>
            Submit
          </Button>
        </VStack>
      </FormProvider>
    </VStack>
  );
};
