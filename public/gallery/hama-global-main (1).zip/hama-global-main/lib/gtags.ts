// lib/gtag.ts
declare global {
  interface Window {
    gtag: (
      command: "config" | "event" | "set" | "get",
      measurementId: string,
      params?: Record<string, unknown>
    ) => void;
  }
}

export const GA_MEASUREMENT_ID = "G-WFNH26PSKF";

export const pageview = (url: string) => {
  window.gtag("config", GA_MEASUREMENT_ID, {
    page_path: url,
    page_title: document.title,
  });
};
