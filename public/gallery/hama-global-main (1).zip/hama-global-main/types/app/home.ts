import { HomePageAPIResponseType } from "../api";

export type HeroSectionProps = {
  initialData: HomePageAPIResponseType;
};
