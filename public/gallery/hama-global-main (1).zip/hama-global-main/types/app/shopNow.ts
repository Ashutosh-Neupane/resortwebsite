export type ShopNowType = {
    hero_title: string;
    hero_description: string;
    hero_image_link: string;
    footer_title: string;
    footer_description: string;
    footer_image_link: string;
    offers: OfferType[];

}
export type OfferType = {
    offer: string;
    
}
export type ShopNowAPIResponseType = {
  Data: ShopNowType;
};
