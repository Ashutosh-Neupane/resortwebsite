import { ValueChangeDetails } from "@zag-js/radio-group";

export type PaymentMethodProps = {
  selectedPaymentMethod: string;
  handlePaymentMethodChange: (details: ValueChangeDetails) => void;
  setDeliveryAddress: (address: string) => void;
  setBillingAddress: (address: string) => void;
  setDeliveryNote: (note: string) => void;
  setReferenceCode: (referenceCode: string) => void;
  setSurgeCharge: (surgeCharge: number) => void;
};

export type SummaryProps = {
  selectedPaymentMethod: string;
  delivery_Address: string;
  billing_Address: string;
  delivery_note: string;
  referenceCode: string;
  surge_charges: number;
};
