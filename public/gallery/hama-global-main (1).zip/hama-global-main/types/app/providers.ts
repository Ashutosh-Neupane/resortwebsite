import { ConfigType } from "../config";

export type ProvidersProps = {
  children: React.ReactNode;
  config: ConfigType;
};
