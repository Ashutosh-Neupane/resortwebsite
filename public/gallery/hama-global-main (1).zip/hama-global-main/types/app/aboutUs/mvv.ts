import { AboutUsPageType } from "@/types/api";

export type MvvProps = {
  data: AboutUsPageType;
};
