import { AboutUsPageType } from "@/types/api";

export type OurMissionProps = {
  data: AboutUsPageType;
};
