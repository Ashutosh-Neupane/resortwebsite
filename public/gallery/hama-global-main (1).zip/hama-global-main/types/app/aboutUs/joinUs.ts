import { AboutUsPageType } from "@/types/api";

export type JoinUsProps = {
  data: AboutUsPageType;
};
