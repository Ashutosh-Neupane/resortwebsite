import { AboutUsPageType } from "@/types/api";

export type TestimonialsProps = {
  data: AboutUsPageType;
};
