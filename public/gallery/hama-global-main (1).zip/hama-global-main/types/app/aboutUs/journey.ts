import { AboutUsPageType } from "@/types/api";

export type JourneyProps = {
  data: AboutUsPageType;
};
