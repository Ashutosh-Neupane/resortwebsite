import { AboutUsPageType } from "@/types/api";

export type WhychooseProps = {
  data: AboutUsPageType;
};
