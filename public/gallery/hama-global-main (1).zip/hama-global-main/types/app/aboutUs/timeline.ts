import { AboutUsPageType } from "@/types/api";

export type TimelineProps = {
  data: AboutUsPageType;
};
