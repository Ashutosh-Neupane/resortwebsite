import { AboutUsPageType } from "@/types/api";

export type TeamSectionProps = {
  data: AboutUsPageType;
};
