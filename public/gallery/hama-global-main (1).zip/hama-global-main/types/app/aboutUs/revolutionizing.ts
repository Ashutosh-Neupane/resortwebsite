import { AboutUsPageType } from "@/types/api";

export type RevolutionizingProps = {
  data: AboutUsPageType;
};
