export type ProductImageThumbnailProps = {
  productImages: string[];
  selectedImage: string;
  setSelectedImage: (image: string) => void;
  productName: string;
};
