import { IndividualProductAPIType } from "@/types/api";

export type ProductImageDisplayProps = {
  selectedImage: string;
  productName: string;
  productDetail: IndividualProductAPIType;
};
