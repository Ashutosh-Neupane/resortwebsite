export type ProductSectionProps = {
  type: "bestSellers" | "newArrivals";
};
