export type OrderPostType = {
  items: {
    item_code: string;
    qty: number;
    rate: number;
  }[];
  selectedPaymentMethod: string;
  referenceCode?: string;
  coupon_code?: string;
  delivery_location?: string;
  delivery_address: string;
  billing_address: string;
  delivery_note?: string;
  surge_charges?: number;
  shipping?: number;
  discount?: number;
};
