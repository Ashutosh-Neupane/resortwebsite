export interface Invoice {
  name: string;
  posting_date: string;
  status: 'Unpaid' | 'Paid' | 'Partially Paid' | string;
  grand_total: number;
  outstanding_amount: number;
  customer: string;
  payment_status: 'Pending' | 'Completed' | 'Failed' | string;
  order_id: string;
  currency: string;
  description: string;
  returnurl: string;
  cancelurl: string;
  amount: number;
  pdf_url: string;
  items: [
    {
      item_code: string;
      item_name: string;
      qty: string;
      rate: number;
      amount: number;
      image_url: string;
    },
];
}
export interface InvoiceAPIResponseType {
  message: Invoice[];
}
