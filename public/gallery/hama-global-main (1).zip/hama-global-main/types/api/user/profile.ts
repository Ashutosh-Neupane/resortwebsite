export type AddressInfoType = {
  address: string;
  address_type: string;
};

export type UserProfileType = {
  customer_name: string;
  custom_phone: string;
  custom_address: string;
  custom_customer_contact: string;
  password_changed: number;
  user: string;
  address_info: AddressInfoType[];
};
