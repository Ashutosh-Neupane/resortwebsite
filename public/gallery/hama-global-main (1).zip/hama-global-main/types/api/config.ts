import { ConfigType } from "../config";

export type ConfigAPIResponse = {
  Data: ConfigType;
};
