export interface StripeAPIResponse {
  message: {
    url: string;
  };
}
