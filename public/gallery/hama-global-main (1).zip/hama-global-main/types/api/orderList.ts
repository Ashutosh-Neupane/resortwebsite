export type OrderType = {
  name: string;
  transaction_date: string;
  status: string;
  grand_total: number;
  amount: number;
  customer: string;
  payment_status: string;
  description: string;
  returnurl: string;
  cancelurl: string;
  currency: string;
  payment_url: string;
  items: [
    {
      item_code: string;
      item_name: string;
      qty: string;
      rate: number;
      amount: number;
      image_url: string;
    },
  ];
};

export type OrderAPIResponseType = {
  message: OrderType[];
};
