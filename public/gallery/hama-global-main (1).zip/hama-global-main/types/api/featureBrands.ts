export type FeaturedBrandsItem = {
  name: string;
  custom_brand_logo_link: string;
};
  
  export type FeaturedBrandsAPIResponseType = {
    data: FeaturedBrandsItem[];
  };
  