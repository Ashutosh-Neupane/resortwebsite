export type ResendOtpApiType = {
  email: string;
};
