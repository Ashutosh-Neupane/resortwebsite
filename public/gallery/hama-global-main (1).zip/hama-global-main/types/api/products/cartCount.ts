export type CartCountAPIResponseType = {
  data: {
    count: number;
  };
};
