export type BrandType = {
  name: string;
};

export type BrandAPIResponseType = {
  Data: BrandType[];
};
