export type PromoCouponType = {
  coupon: string;
  delivery_charge: string;
  online_payment_choosed:number;
  bsb_choosed:number;
};

export type PromoCouponResponseData = {
  message: string;
  data: {
    total: number;
    total_tax: number;
    total_after_tax: number;
    discount_amount: number;
    grand_total_after_discount: number;
    delivery_charge: number;
    surge_charges: number;
    final_total: number;
  };
};

export type PromoFormData = {
  promoCode: string;
  deliveryLocation: string;
};

export type PromoData = {
  total: number;
  total_tax: number;
  total_after_tax: number;
  discount_amount: number;
  grand_total_after_discount: number;
  surge_charges: number;
  delivery_charge: number;
  final_total: number;
  delivery_location?: string;
};

export type PromoFormState = {
  promoCode: string;
  deliveryLocation: string;
  surgeCharge: number;
  resetFlag: boolean;
  setPromoCode: (code: string) => void;
  setDeliveryLocation: (location: string) => void;
  setSurgeCharge: (surgeCharge: number) => void;
  resetPromoForm: () => void;
  clearResetFlag: () => void;
};
