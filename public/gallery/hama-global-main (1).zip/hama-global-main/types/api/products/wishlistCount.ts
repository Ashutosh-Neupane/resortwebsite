export type WishlistCountAPIResponseType = {
  data: {
    count: number;
  };
};
