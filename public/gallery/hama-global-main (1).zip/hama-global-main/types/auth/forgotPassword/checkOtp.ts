export type CheckOtpType = {
  email: string;
  otp: string;
};
