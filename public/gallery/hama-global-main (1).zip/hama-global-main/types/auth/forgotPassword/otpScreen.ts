export type OtpScreenType = {
  email: string;
};
