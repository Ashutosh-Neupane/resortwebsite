export type ResetPasswordType = {
  email: string;
  npwd: string;
};

export type GetOtpType = {
  email: string;
};
