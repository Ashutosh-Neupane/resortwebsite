import Image from "next/image";
import { useEffect } from "react";
import { Box, Button, HStack, VStack } from "@chakra-ui/react";

import { CloseCircleIcon } from "@/assets/svg";
import { AccordionRoot, Drawer, VisibleSection } from "@/components";
import { useConfigQuery, useUserProfileQuery } from "@/hooks/api";
import { SidebarProps } from "@/types";

import { SidebarItem } from "./SidebarItem";
import { calculateHeightAndWidth, extractMenu } from "@/utils";
import { useLayoutDialogStore, useRegisterDialogStore } from "@/store";

export const Sidebar = ({ isOpen, onClose }: SidebarProps) => {
  const { data: config } = useConfigQuery();
  const { updateSignInOpen } = useLayoutDialogStore();
  const { updateSignUpOpen } = useRegisterDialogStore();

  const { data: userProfileData, isError } = useUserProfileQuery();
  const isAuthenticated = !!userProfileData && !isError;
  const navItems = extractMenu(config.menu_table, isAuthenticated);
  const { height, width } = calculateHeightAndWidth(
    config.width,
    config.height
  );

  // Automatically closes the component(sidebar and modal) when the window is resized to desktop width (1024px or more)
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        onClose();
      }
    };
    window.addEventListener("resize", handleResize);
    // Cleanup the event listener on component unmount
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <Drawer
      open={isOpen}
      onClose={onClose}
      placement="start"
      hasHeader={false}
      hasFooter={false}
      hasCloseIcon={false}
    >
      <VStack
        alignItems="stretch"
        gap="24px"
        padding="20px 16px"
        color="primary.400"
      >
        <HStack justifyContent="space-between" color="danger.100">
          <Box position="relative" width={`${width}px`} height={`${height}px`}>
            <Image
              src={config.company_details_url}
              alt={config.company_details_name}
              fill
              loading="eager"
            />
          </Box>

          <CloseCircleIcon onClick={onClose} />
        </HStack>

        <AccordionRoot collapsible>
          {navItems.map((navItem, index) => (
            <SidebarItem
              onClose={onClose}
              key={navItem.menuName}
              {...navItem}
              isLastChild={index === navItems.length - 1}
            />
          ))}
        </AccordionRoot>
        {/* for login and register button */}
        {!userProfileData && (
          <Box display="flex" flexWrap={"wrap"} gap="8px" width="100%">
            <VisibleSection visibility={config?.login_visibility}>
              <Button
                color="black"
                bg="gray.200"
                borderRadius="full"
                cursor="pointer"
                width="full"
                onClick={() => updateSignInOpen(true)}
              >
                Login
              </Button>
            </VisibleSection>

            <VisibleSection visibility={config?.register_visibility}>
              <Button
                color="white"
                bg="#16CA5E"
                borderRadius="full"
                cursor="pointer"
                w={"full"}
                onClick={() => updateSignUpOpen(true)}
              >
                Partner With Us
              </Button>
            </VisibleSection>
          </Box>
        )}
      </VStack>
    </Drawer>
  );
};
