import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { Box, Button, Flex, HStack, useDisclosure } from "@chakra-ui/react";

import { LoginDialog, RegisterDialog, SearchDialog } from "@/components";
import { navbarIconsList, ROUTES } from "@/constants";
import {
  useCartCountQuery,
  useConfigQuery,
  useUserProfileQuery,
  useWishlistCountQuery,
} from "@/hooks/api";
import { useAuthentication } from "@/hooks/app";
import { useLayoutDialogStore, useRegisterDialogStore } from "@/store";
import { calculateHeightAndWidth, extractMenu } from "@/utils";

import { NavItem } from "./NavItem";
import { Sidebar } from "../sidebar";
import { VisibleSection } from "@/components/ui/visibleSection";
import { ProfileDropdown } from "@/app/(user)/profile";

export const Navbar = () => {
  const { data: config } = useConfigQuery();

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const {
    open: isSearchOpen,
    onOpen: onSearchOpen,
    onClose: onSearchClose,
  } = useDisclosure();

  const { height, width } = calculateHeightAndWidth(
    config.width,
    config.height
  );

  const { authenticate } = useAuthentication();

  const { signInOpen, updateSignInOpen } = useLayoutDialogStore();
  const { signUpOpen, updateSignUpOpen } = useRegisterDialogStore();

  const { data: wishlistCount } = useWishlistCountQuery();
  const { data: cartCount } = useCartCountQuery();
  const { data: userProfileData, isLoading, isError } = useUserProfileQuery();

  const wishlistTotalCount = wishlistCount?.count ?? "";
  const cartTotalCount = cartCount?.count ?? "";

  const isAuthenticated = !!userProfileData && !isError;
  const navItems = extractMenu(config.menu_table, isAuthenticated);

  return (
    <>
      <HStack
        position="sticky"
        top="0"
        bg={"white"}
        shadow={"sm"}
        zIndex={30}
        alignItems="center"
        px={{
          base: "16px",
          lg: "24px",
          xl: "32px",
          "2xl": "40px",
        }}
      >
        <HStack
          justifyContent="space-between"
          mx="auto"
          maxWidth="1280px"
          width="full"
          color="system.text.normal.dark"
        >
          <Link href={ROUTES.APP.HOMEPAGE}>
            <Box position="relative" width={180} height={70} marginLeft={{base:"-2.5rem",md:"0"}}>
              <Image
                src={config.company_details_url}
                alt={config.company_details_name}
                loading="eager"
                fill
              />
            </Box>
          </Link>

          <HStack
            display={{
              base: "none", // Hide on mobile
              lg: "flex", // Show on desktop
            }}
            gap="16px"
          >
            {navItems.map(({ href, menuName, subMenus }) => (
              <NavItem
                key={menuName}
                href={href}
                menuName={menuName}
                subMenus={subMenus}
              />
            ))}

            {/* Desktop: Profile, Cart, Wishlist,profile Icons */}
            {!isLoading && (
              <>
                <VisibleSection visibility={config?.search_box_visibility}>
                  <Box cursor="pointer" onClick={onSearchOpen}>
                    {navbarIconsList[0].icon}
                  </Box>
                </VisibleSection>
                {userProfileData && !isError ? (
                  <HStack gap="24px" color="primary.400">
                    <VisibleSection visibility={config?.wishlist_visibility}>
                      <Box
                        cursor="pointer"
                        position="relative"
                        onClick={() =>
                          authenticate(navbarIconsList[1].href, () =>
                            updateSignInOpen(true)
                          )
                        }
                      >
                        <Flex position="relative">
                          {navbarIconsList[1].icon}
                          {wishlistTotalCount !== "" &&
                            wishlistTotalCount > 0 && (
                              <Box
                                position="absolute"
                                top="-1"
                                right="-1"
                                bg="red.500"
                                color="white"
                                fontSize="8px"
                                borderRadius="full"
                                w="3.5"
                                h="3.5"
                                display="flex"
                                alignItems="center"
                                justifyContent="center"
                              >
                                {wishlistTotalCount}
                              </Box>
                            )}
                        </Flex>
                      </Box>
                    </VisibleSection>

                    <VisibleSection visibility={config?.cart_visibility}>
                      <Box
                        cursor="pointer"
                        onClick={() =>
                          authenticate(navbarIconsList[2].href, () =>
                            updateSignInOpen(true)
                          )
                        }
                      >
                        <Flex position="relative">
                          {navbarIconsList[2].icon}
                          {cartTotalCount !== "" && cartTotalCount > 0 && (
                            <Box
                              position="absolute"
                              top="-1"
                              right="-1"
                              bg="red.500"
                              color="white"
                              fontSize="8px"
                              borderRadius="full"
                              w="3.5"
                              h="3.5"
                              display="flex"
                              alignItems="center"
                              justifyContent="center"
                            >
                              {cartTotalCount}
                            </Box>
                          )}
                        </Flex>
                      </Box>
                    </VisibleSection>
                    {/* profile icon with dropdown */}
                    <ProfileDropdown />
                  </HStack>
                ) : (
                  <>
                    <Box display="flex" gap="8px">
                      <VisibleSection visibility={config?.login_visibility}>
                        <Button
                          color="black"
                          bg="gray.200"
                          borderRadius={"sm"}
                          cursor="pointer"
                          onClick={() => updateSignInOpen(true)}
                        >
                          Login
                        </Button>
                      </VisibleSection>

                      <VisibleSection visibility={config?.register_visibility}>
                        <Button
                          color="white"
                          bg="#16CA5E"
                          cursor="pointer"
                          borderRadius={"sm"}
                          onClick={() => updateSignUpOpen(true)}
                        >
                          Partner With Us
                        </Button>
                      </VisibleSection>
                    </Box>
                  </>
                )}
              </>
            )}
          </HStack>

          {/* Mobile View (Before Hamburger Icon) */}
          <Box
            display={{
              base: "flex",
              lg: "none",
            }}
            gap={{base:"10px" ,md:"16px"}}
            alignItems={"center"}
            color={"black"}
          >
            <Box cursor="pointer" onClick={onSearchOpen}>
              {navbarIconsList[0].icon}
            </Box>
            {!isLoading && userProfileData && !isError && (
              <>
                {/* Wishlist, Cart, Profile Icons */}
                <VisibleSection visibility={config?.wishlist_visibility}>
                  <Box
                    cursor="pointer"
                    position="relative"
                    onClick={() =>
                      authenticate(navbarIconsList[1].href, () =>
                        updateSignInOpen(true)
                      )
                    }
                  >
                    {navbarIconsList[1].icon}
                    {wishlistTotalCount !== "" && wishlistTotalCount > 0 && (
                      <Box
                        position="absolute"
                        top="-1"
                        right="-1"
                        bg="red.500"
                        color="white"
                        fontSize="8px"
                        borderRadius="full"
                        w="3.5"
                        h="3.5"
                        display="flex"
                        alignItems="center"
                        justifyContent="center"
                      >
                        {wishlistTotalCount}
                      </Box>
                    )}
                  </Box>
                </VisibleSection>

                <VisibleSection visibility={config?.cart_visibility}>
                  <Box
                    cursor="pointer"
                    position="relative"
                    onClick={() =>
                      authenticate(navbarIconsList[2].href, () =>
                        updateSignInOpen(true)
                      )
                    }
                  >
                    {navbarIconsList[2].icon}
                    {cartTotalCount !== "" && cartTotalCount > 0 && (
                      <Box
                        position="absolute"
                        top="-1"
                        right="-1"
                        bg="red.500"
                        color="white"
                        fontSize="8px"
                        borderRadius="full"
                        w="3.5"
                        h="3.5"
                        display="flex"
                        alignItems="center"
                        justifyContent="center"
                      >
                        {cartTotalCount}
                      </Box>
                    )}
                  </Box>
                </VisibleSection>

                {/*<Box
                  cursor="pointer"
                  color={"black"}
                  onClick={() =>
                    authenticate(navbarIconsList[3].href, () =>
                      updateSignInOpen(true)
                    )
                  }
                >
                  {navbarIconsList[3].icon}
                </Box>*/}
                <ProfileDropdown />
              </>
            )}
            {/* Hamburger Icon */}
            <Box
              display={{
                base: "block", // Show on mobile
                lg: "none", // Hide on desktop
              }}
              cursor="pointer"
              color={"black"}
              onClick={() => setIsSidebarOpen(true)}
            >
              {navbarIconsList[4].icon}
            </Box>
          </Box>
        </HStack>
      </HStack>

      {/* Sidebar and Dialogs */}
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      <SearchDialog open={isSearchOpen} onClose={onSearchClose} />
      <LoginDialog open={signInOpen} onClose={() => updateSignInOpen(false)} />
      <RegisterDialog
        open={signUpOpen}
        onClose={() => updateSignUpOpen(false)}
      />
    </>
  );
};
