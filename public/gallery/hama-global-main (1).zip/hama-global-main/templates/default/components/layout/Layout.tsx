"use client";

import { usePathname } from "next/navigation";
import { useConfigQuery } from "@/hooks/api";
import { LayoutProps } from "@/types";

// import { Topbar } from "./topbar";
import { Navbar } from "./navbar";
import { Footer } from "./footer";

export const Layout = ({ children, config }: LayoutProps) => {
  // set config data fetched from the server to the react query
  const pathname = usePathname();

  const hideLayoutOn = ["/checkout","/payment-success"];

  const shouldHideLayout = hideLayoutOn.includes(pathname);

  useConfigQuery({ Data: config });

  return (
    <>
      {/* <Topbar /> */}
      {!shouldHideLayout && <Navbar />}

      {children}

      {!shouldHideLayout && <Footer />}
    </>
  );
};
