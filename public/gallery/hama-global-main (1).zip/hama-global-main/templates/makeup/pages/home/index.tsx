import { Text, VStack } from "@chakra-ui/react";

export const MakeupLandingPage = () => {
  return (
    <VStack>
      <Text>Hello Makeup Landing Page</Text>
    </VStack>
  );
};
