// remove all images when it is dynamic

export { default as DummyLogo } from "./dummy-logo.png";

export { default as ProductImage1 } from "./product-1.png";
export { default as AuthBannerImage } from "./auth-banner.png";
export { default as DummyProfileImage } from "./dummy-profile.png";
export { default as BlueJeansImage } from "./blue-jeans.png";

//payment methods
export { default as StripeImage } from "./stripe.png";
export { default as CashOnDeliveryImage } from "./cash-on-delivery.png";
export { default as onlinePaymentImage } from "./online.png";
export { default as COD } from "./cod.png";

// empty state
export { default as EmptyStateImage } from "./empty-state.png";
export { default as DNDTS } from "./dndts.png";
export * from "./auth";
