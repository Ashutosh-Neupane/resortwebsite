export { default as EmailVerificationImage } from "./email-verification.png";
export { default as GoogleImage } from "./google.png";
export { default as MetaImage } from "./meta.png";
