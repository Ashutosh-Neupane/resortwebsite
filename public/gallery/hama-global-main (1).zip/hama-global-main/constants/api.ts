import { POST } from "@/app/api/auth/login/route";

export const API_ROUTES = {
  AUTH: {
    LOGIN: "frappe.val.api.login",
    REGISTER: "signup",
    USERREGISTER: "userregistrationform",
    SET_PASSWORD: "resetpassword",
    RESEND_OTP: "resendotp",
    FORGOT_PASSWORD: {
      GET_OTP: "forgotpasswordgetotp",
      OTP_CHECK: "forgotpasswordotpcheck",
      CHANGE_PASSWORD: "changepw",
    },
  },

  APP: {
    CONFIG: "websiteconfig",
    FAQ: "faq",
    SAAF: "singlebrand",
    QUALITY: "quality",

    HOMEPAGE: "homepage",
    FEATURED_CATEGORY: "featuredcategories",
    FEATURED_BRAND: "featuredbrands",
    SHOP_NOW: "shop_now",

    PRODUCTS: {
      FILTER: "itemflags",
      LIST: "item_list",
      SEARCH: "item_search",
      OFFER: "offeritems",

      NEW_ARRIVALS: "newarrivals",
      BEST_SELLERS: "bestseller",

      PRODUCTS_LIKE: "productslike",
      ITEM_PRODUCTS_LIKE: "itemproductslike",

      REVIEW_DATA: "reviewdata",
      REVIEW: "review",
      PAYMENT_METHOD: "modeofpayment",

      WISHLIST: {
        ADD: "postwishlist",
        GET: "wishlistdata",
        REMOVE: "removewishlist",
        COUNT: "wishlistdatacount",
      },

      CART: {
        ADD: "postcart",
        ADD_NEW: "postcartcheckout",
        GET: "cartdata",
        REMOVE: "removecart",
        COUNT: "cartdatacount",
        STRIPE:
          "dndtsecommerce.dndts_ecommerce.page.stripe_payment.stripe_payment.create_checkout_session",
        PAYMENT_ENTRY: "payment_entry",
      },

      INDIVIDUAL_PRODUCT: {
        GET: "individualitem",
      },
    },

    CATEGORIES: {
      LIST: "items_group",
    },

    BRANDS: {
      LIST: "fetchbrands",
    },

    ABOUT_US: "about_us",

    CONTACT_US: {
      DETAIL: "contact-us",
      SUBMIT: "contact-us-post",
    },
    TERMS_AND_CONDITION: {
      LIST: "terms",
    },
    PRIVACY_POLICY: {
      LIST: "privacy",
    },
    RETURN_POLICY: {
      LIST: "return",
    },
    ORDER: {
      POST: "orderpost",
      LIST: "orderlist",
      DELIVERY: "deliverycharges",
    },
    INVOICE: {
      LIST: "invoicelist",
    },
    PROMO: {
      POST: "couponcalculation",
      GET: "couponcalculation",
    },
  },

  USER: {
    PROFILE: {
      GET: "userdetail",
    },
    NEW_ADDRESS: {
      POST: "newaddress",
    },
  },
};

export const NEXT_API_ROUTES = {
  AUTH: {
    LOGIN: "/api/auth/login",
    REGISTER: "/api/auth/register",
    USERREGISTER: "/api/auth/userregistrationform",
    SET_PASSWORD: "/api/auth/setpassword",
    RESEND_OTP: "api/auth/resendotp",
    FORGOT_PASSWORD: {
      GET_OTP: "api/auth/forgotpassword/getotp",
      OTP_CHECK: "api/auth/forgotpassword/checkotp",
      CHANGE_PASSWORD: "api/auth/forgotpassword/changepassword",
    },
  },
};
