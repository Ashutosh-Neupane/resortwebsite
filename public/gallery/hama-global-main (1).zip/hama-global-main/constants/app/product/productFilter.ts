export const priceRangeFilterOptions = [
  // {
  //   label: "Price Range",
  //   value: "0",
  // },
  {
    label: "Low to High",
    value: "1",
  },
  {
    label: "High to Low",
    value: "2",
  },
];

export const popularityFilterOptions = [
  // {
  //   label: "Popularity",
  //   value: "0",
  // },
  {
    label: "Best Selling",
    value: "1",
  },
  {
    label: "New Arrivals",
    value: "2",
  },
];

export const PAGE_SIZE = 12;
