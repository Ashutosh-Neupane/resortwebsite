export const ROUTES = {
  APP: {
    HOMEPAGE: "/",

    SEARCH: "/search",
    ABOUT_US: "/about-us",
    FAVORITE: "/favorite",
    PRODUCTS: "/products",
    INDIVIDUAL_PRODUCT: "/products/:productName",
    CONTACT_US: "/contact-us",
    PAYMENT: "/payment",
    PRIVACY: "/privacy-policy",
    RETURN: "/return-policy",
    TERMS: "/terms-and-condition",
    SHOP_NOW: "/shop-now",
    OFFER: "/offer",
  },

  USER: {
    CART: "/cart",
    FAVORITE: "/favorite",
    PROFILE: "/profile",
    CHECKOUT: "/checkout",
  },
  SAAF: "/saaf",

  NOT_FOUND: "/not-found",
  DEFAULT: "#",
};
