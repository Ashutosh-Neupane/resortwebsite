import { API_ROUTES } from "@/constants";
import { httpClient } from "@/lib";
import { OrderPostType } from "@/types";

export const orderPost = (data: OrderPostType) => {
  return httpClient.post(API_ROUTES.APP.ORDER.POST, {
    items: data.items,
    selectedPaymentMethod: data.selectedPaymentMethod,
    reference_code: data.referenceCode,
    discount: data.discount,
    shipping: data.shipping,
    coupon_code: data.coupon_code,
    delivery_location: data.delivery_location,
    delivery_note: data.delivery_note,
    delivery_address: data.delivery_address,
    surge_charges: data.surge_charges,
    billing_address: data.billing_address,
  });
};
