import { API_ROUTES } from "@/constants";
import { useCheckoutStore } from "@/store/products/checkoutStore";
import { StripeAPIResponse } from "@/types/api/stripe";

// Function to get Stripe data
export const getStripeData = async (): Promise<StripeAPIResponse> => {
  const checkoutData = useCheckoutStore.getState().checkoutData;

  // Ensure checkout data exists
  if (!checkoutData) {
    throw new Error("Checkout data is missing");
  }

  const {
    order_id,
    customer,
    currency,
    description,
    returnurl,
    cancelurl,
    amount,
  } = checkoutData;

  const response = await fetch(
    process.env.NEXT_PUBLIC_API_ENDPOINT + API_ROUTES.APP.PRODUCTS.CART.STRIPE,
    {
      cache: "no-cache",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        order_id,
        customer,
        currency,
        description,
        returnurl,
        cancelurl,
        amount,
      }),
    }
  );

  // Parse the response
  const data = await response.json();

  return data as StripeAPIResponse;
};
