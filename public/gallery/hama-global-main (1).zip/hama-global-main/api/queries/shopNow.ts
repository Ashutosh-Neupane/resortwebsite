import { API_ROUTES } from "@/constants";
import { ShopNowAPIResponseType } from "@/types";

export const getShopNowPageData = async (): Promise<ShopNowAPIResponseType> => {
  const response = await fetch(
    process.env.NEXT_PUBLIC_API_ENDPOINT + API_ROUTES.APP.SHOP_NOW,
    {
      cache: "no-cache",
      method: "POST",
    }
  );

  const data = await response.json();
  console.log("data", data)
  return data;
};
