import { API_ROUTES } from "@/constants";
import { httpClient } from "@/lib";

interface SavePaymentResponse {
  message: string;
}

export const savePayment = async (
  orderId: string
): Promise<SavePaymentResponse> => {
  const payload = { order_id: orderId };

  const response = await httpClient.post<SavePaymentResponse>(
    API_ROUTES.APP.PRODUCTS.CART.PAYMENT_ENTRY,
    payload
  );
  return response.data;
};
