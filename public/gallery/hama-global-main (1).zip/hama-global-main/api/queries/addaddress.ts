import { API_ROUTES } from "@/constants";
import { httpClient } from "@/lib";

type NewAddressPayload = {
  address_type: string;
  address: string;
};
export type NewAddressPayloadType = {
  data : NewAddressPayload[];
}

export const postNewAddress = async (payload: NewAddressPayload): Promise<NewAddressPayloadType> => {
    return httpClient.post(API_ROUTES.USER.NEW_ADDRESS.POST, payload);
};
