import { API_ROUTES } from "@/constants";
import { httpClient } from "@/lib";
import { InvoiceAPIResponseType } from "@/types";

export const getInvoiceData = async () => {
  return httpClient.get<InvoiceAPIResponseType>(API_ROUTES.APP.INVOICE.LIST);
};
