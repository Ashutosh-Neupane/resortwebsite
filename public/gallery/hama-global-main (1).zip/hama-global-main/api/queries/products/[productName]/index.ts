export * from "./productDetail";
