export * from "./HeroSection";
export * from "./Discover";
export * from "./ArrangementSection";
export * from "./AwarenessSection";
export * from "./SmartErpSection";
