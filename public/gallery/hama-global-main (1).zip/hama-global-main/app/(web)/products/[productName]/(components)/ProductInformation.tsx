// "use client";

// import { useParams } from "next/navigation";
// import { useState } from "react";
// import { Flex, Heading, HStack, Stack, Text, VStack } from "@chakra-ui/react";

// import { HeartIcon } from "@/assets/svg";
// import { Button, ProductVariantTabs, QuantityInput } from "@/components";
// import {
//   useConfigQuery,
//   useProductDetailByNameQuery,
//   useUserProfileQuery,
// } from "@/hooks/api";
// import {
//   useAuthCheck,
//   useProductDetailCartMutation,
//   useProductDetailWishlist,
// } from "@/hooks/app";

// import { ProductDescription } from "./ProductDescription";
// import { ProductReviews } from "./ProductReviews";
// import { VisibleSection } from "@/components/ui/visibleSection";

// export const ProductInformation = () => {
//   const params = useParams();

//   const productName = params.productName as string;

//   const { data: config } = useConfigQuery();

//   const { data: productDetail } = useProductDetailByNameQuery(productName);

//   const { handleAddToCart, isPending: isCartPending } =
//     useProductDetailCartMutation();
//   const { handleAddToWishlist, isPending: isWishlistPending } =
//     useProductDetailWishlist();

//   const minimumQuantity = productDetail?.custom_minimum_order_quantity || 1;
//   const maximumQuantity = productDetail?.custom_maximum_order_quantity || 100;
//   const incrementStep = productDetail?.custom_increment_on_quantity || 1;

//   const [quantity, setQuantity] = useState(minimumQuantity);

//   const handleQuantityChange = (newQuantity: number) => {
//     if (newQuantity < minimumQuantity || newQuantity > maximumQuantity) return;

//     setQuantity(newQuantity);
//   };

//   const price = productDetail?.prices?.[0]?.price_list_rate;

//   const onAddToWishlist = () => {
//     const payload = {
//       item_code: productDetail?.item_code,
//       quantity,
//     };

//     handleAddToWishlist(payload);
//   };

//   const onAddToCart = () => {
//     const payload = {
//       item_code: productDetail?.item_code,
//       item_price: price || "",
//       quantity,
//     };
//     handleAddToCart(payload);
//   };

//   const { checkAuth } = useAuthCheck();
//   const { data: userProfileData } = useUserProfileQuery();

//   // Check if product is out of stock or not
//   const isOutOfStock =
//     productDetail?.stock_qty !== undefined && productDetail.stock_qty <= 0;

//   return (
//     <Flex flex={1} flexDirection="column" width="100%">
//       <VStack
//         alignItems="stretch"
//         gap={{ base: "20px", lg: "28px" }}
//         paddingTop={{ base: "24px", md: "0" }}
//         paddingBottom={{ base: "24px", lg: "40px" }}
//         borderBottom={{ base: 0, md: "1px solid" }}
//         borderColor={{ md: "system.neutral.separator.light" }}
//       >
//         {/* title */}
//         <Stack gap={{ base: "12px", lg: "24px" }} width="100%">
//           <Stack gap="12px">
//             <HStack justifyContent="space-between">
//               <Text
//                 color="system.text.light.light"
//                 variant="subtitle2"
//                 fontSize={{ base: "12px", lg: "14px" }}
//               >
//                 {productDetail?.item_group}
//               </Text>
//               {/* <Text
//                 color="system.text.light.light"
//                 variant="subtitle2"
//                 fontSize={{ base: "12px", lg: "14px" }}
//               >
//                 {productDetail?.item_code}
//               </Text> */}
//             </HStack>

//             <Heading
//               color="black"
//               fontSize={{
//                 base: "20px",
//                 lg: "24px",
//                 xl: "28px",
//               }}
//             >
//               {productDetail?.item_name}
//             </Heading>
//           </Stack>
//           <HStack gap="0">
//             <VisibleSection visibility={config?.rate_visibility}>
//               {userProfileData && (
//                 <Heading variant="heading6" fontWeight="400">
//                   {config.currency} {price}
//                 </Heading>
//               )}
//             </VisibleSection>

//             {/* <Text
//               variant="subtitle1"
//               color="danger.100"
//               paddingLeft="12px"
//               textDecoration="line-through"
//             >
//               रु{productDetail.originalPrice}
//             </Text>

//             <Text
//               variant="subtitle2"
//               borderRadius="8px"
//               color="system.text.light.light"
//               paddingLeft="4px"
//             >
//               -{productDetail.discount}
//             </Text> */}
//           </HStack>
//         </Stack>

//         {productDetail?.variants && (
//           <Stack gap="12px">
//             <Text variant="subtitle1" color="system.text.normal.light">
//               Choose Variant
//             </Text>

//             <ProductVariantTabs variants={productDetail?.variants} />
//           </Stack>
//         )}

//         {/* size */}
//         {/* <Stack gap="12px" py={{ base: "24px", lg: "32px" }}>
//           <HStack gap="0">
//             <Text variant="subtitle1" color="system.text.normal.light">
//               Choose Size
//             </Text>
//             <Text
//               variant="subtitle2"
//               fontSize="14px"
//               color="system.text.light.light"
//             >
//               * All size are in EU
//             </Text>
//           </HStack>
//           <HStack gap="12px">
//             {productDetail?.sizes?.map((size, index) => (
//               <Text
//                 key={index}
//                 variant="subtitle1"
//                 color="system.text.primary.primary.light"
//                 border="1px solid"
//                 borderColor="system.neutral.separator.light"
//                 padding="12px 16px"
//                 width="fit-content"
//               >
//                 {size}
//               </Text>
//             ))}
//           </HStack>
//         </Stack> */}

//         {!isOutOfStock && (
//           <VisibleSection visibility={config?.cart_visibility}>
//             {/* quantity */}
//             <Stack gap="12px">
//               <Text variant="subtitle1" color="system.text.normal.light">
//                 Quantity
//               </Text>
//               <QuantityInput
//                 value={quantity}
//                 onChange={handleQuantityChange}
//                 minimum={minimumQuantity}
//                 maximum={maximumQuantity}
//                 incrementStep={incrementStep}
//               />
//             </Stack>
//             {/* button */}
//             <HStack gap="20px" width="100%">
//               <VisibleSection visibility={config?.cart_visibility}>
//                 <Button
//                   type="submit"
//                   flex={1}
//                   onClick={checkAuth(onAddToCart)}
//                   loading={isCartPending}
//                 >
//                   Add to Bag
//                 </Button>
//               </VisibleSection>
//               <VisibleSection visibility={config?.wishlist_visibility}>
//                 <Button
//                   variant="outline"
//                   width="170px"
//                   padding="10px 20px"
//                   onClick={checkAuth(onAddToWishlist)}
//                   loading={isWishlistPending}
//                 >
//                   <HeartIcon
//                     style={{
//                       width: "24px",
//                       height: "24px",
//                     }}
//                   />
//                   <Text variant="subtitle1" color="primary.400">
//                     Favorite
//                   </Text>
//                 </Button>
//               </VisibleSection>
//             </HStack>
//           </VisibleSection>
//         )}

//         {isOutOfStock && (
//           <Text color="red.500" fontWeight="semibold">
//             This product is currently out of stock
//           </Text>
//         )}
//       </VStack>

//       {/* description */}
//       <ProductDescription />

//       {/* reviews */}
//       <VisibleSection visibility={config?.cart_visibility}>
//         <ProductReviews item_code={productDetail?.item_code ?? ""} />
//       </VisibleSection>
//     </Flex>
//   );
// };

"use client";

import { useParams, useRouter } from "next/navigation";
import { useState } from "react";
import { Flex, Heading, HStack, Stack, Text, VStack } from "@chakra-ui/react";

import { HeartIcon } from "@/assets/svg";
import {
  Button,
  ProductVariantTabs,
  QuantityInput,
  toaster,
} from "@/components";
import {
  useConfigQuery,
  useProductDetailByNameQuery,
  useUserProfileQuery,
  useCartQuery, // 👈 assuming you have this
} from "@/hooks/api";
import {
  useAuthCheck,
  useProductDetailCartMutation,
  useProductDetailWishlist,
} from "@/hooks/app";

import { ProductDescription } from "./ProductDescription";
import { ProductReviews } from "./ProductReviews";
import { VisibleSection } from "@/components/ui/visibleSection";
import { ROUTES } from "@/constants";
import { MailQuestion } from "lucide-react";

export const ProductInformation = () => {
  const params = useParams();
  const router = useRouter();

  const productName = params.productName as string;

  const { data: config } = useConfigQuery();
  const { data: productDetail } = useProductDetailByNameQuery(productName);
  const { data: cartItems } = useCartQuery();
  const { data: userProfileData } = useUserProfileQuery();

  const { handleAddToCart, isPending: isCartPending } =
    useProductDetailCartMutation();
  const { handleAddToWishlist, isPending: isWishlistPending } =
    useProductDetailWishlist();
  const { checkAuth } = useAuthCheck();

  const minimumQuantity =
    Math.min(
      productDetail?.custom_minimum_order_quantity ?? Infinity,
      productDetail?.stock_qty ?? 0
    ) || 1;
  const maximumQuantity = productDetail?.stock_qty || 100;
  const incrementStep = productDetail?.custom_increment_on_quantity || 1;

  const [quantity, setQuantity] = useState(minimumQuantity);

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity < minimumQuantity || newQuantity > maximumQuantity) return;
    setQuantity(newQuantity);
  };

  const price = productDetail?.prices?.[0]?.price_list_rate;
  const discountPercent = productDetail?.prices?.[0]?.custom_discount_;
  const discountedPrice = productDetail?.prices?.[0]?.discounted_price;

  // Check if product is out of stock
  const isOutOfStock =
    productDetail?.stock_qty !== undefined && productDetail.stock_qty <= 0;
  const limitedCheck =
    productDetail?.stock_qty === minimumQuantity &&
    productDetail?.stock_qty !== undefined;

  // Get quantity of this product already in cart
  const currentCartQuantity =
    cartItems?.find((item) => item?.title === productDetail?.item_code)
      ?.quantity || 0;

  // Calculate remaining stock
  const remainingStockQty =
    (productDetail?.stock_qty || 0) - currentCartQuantity;

  const onAddToWishlist = () => {
    const payload = {
      item_code: productDetail?.item_code,
      quantity,
    };

    handleAddToWishlist(payload);
  };

  const onAddToCart = () => {
    if (quantity > remainingStockQty) {
      toaster.create({
        title: `Only ${remainingStockQty} item's left in stock. You already have ${currentCartQuantity} in your cart.`,
        type: "error",
        duration: 3000,
      });
      return;
    }
    const payload = {
      item_code: productDetail?.item_code,
      item_price: price || "",
      quantity,
    };
    handleAddToCart(payload);
  };

  return (
    <Flex flex={1} flexDirection="column" width="100%">
      <VStack
        alignItems="stretch"
        gap={{ base: "20px", lg: "28px" }}
        paddingTop={{ base: "24px", md: "0" }}
        paddingBottom={{ base: "24px", lg: "40px" }}
        borderBottom={{ base: 0, md: "1px solid" }}
        borderColor={{ md: "system.neutral.separator.light" }}
      >
        {/* title */}
        <Stack gap={{ base: "12px", lg: "24px" }} width="100%">
          <Stack gap="12px">
            <HStack justifyContent="space-between">
              <Text
                color="system.text.light.light"
                variant="subtitle2"
                fontSize={{ base: "12px", lg: "14px" }}
              >
                {productDetail?.item_group}
              </Text>
            </HStack>

            <Heading
              color="black"
              fontSize={{
                base: "20px",
                lg: "24px",
                xl: "28px",
              }}
            >
              {productDetail?.item_name}
            </Heading>
          </Stack>
          <HStack gap="2" align="baseline">
            <VisibleSection visibility={config?.rate_visibility}>
              {userProfileData && (
                <HStack align="baseline" gap="2">
                  {/* Always show current price */}
                  <Heading variant="heading6" fontWeight="400">
                    {config.currency} {discountedPrice}
                  </Heading>

                  {/* Only show original price and discount badge if there's a discount */}
                  {discountPercent ? (
                    <HStack align="center" gap="2">
                      <Heading
                        variant="heading6"
                        color="red.500"
                        textDecoration="line-through"
                        fontWeight="400"
                      >
                        {config.currency} {price}
                      </Heading>

                      {/* <Badge
                        colorScheme="red"
                        variant="solid"
                        borderRadius="md"
                        px="2"
                        py="1"
                        fontSize="sm"
                        fontWeight="bold"
                      >
                        -{discountPercent}% OFF
                      </Badge> */}
                    </HStack>
                  ) : null}
                </HStack>
              )}
            </VisibleSection>
          </HStack>
        </Stack>

        {productDetail?.variants && (
          <Stack gap="12px">
            <Text variant="subtitle1" color="system.text.normal.light">
              Choose Variant
            </Text>
            <ProductVariantTabs variants={productDetail?.variants} />
          </Stack>
        )}

        {!isOutOfStock && (
          <VisibleSection visibility={config?.cart_visibility}>
            <Stack gap="12px">
              <Text variant="subtitle1" color="system.text.normal.light">
                Quantity
              </Text>
              <QuantityInput
                value={quantity}
                onChange={handleQuantityChange}
                minimum={minimumQuantity}
                maximum={maximumQuantity}
                incrementStep={incrementStep}
              />
            </Stack>

            {limitedCheck && (
              <Text color="red.500" fontWeight="semibold">
                Limited Stock Available
              </Text>
            )}

            <HStack gap="20px" width="100%">
              <VisibleSection visibility={config?.cart_visibility}>
                <Button
                  type="submit"
                  flex={1}
                  bg={"#16CA5E"}
                  color={"white"}
                  onClick={checkAuth(onAddToCart)}
                  loading={isCartPending}
                >
                  Add to Bag
                </Button>
              </VisibleSection>
              <VisibleSection visibility={config?.wishlist_visibility}>
                <Button
                  variant="outline"
                  width="170px"
                  padding="10px 20px"
                  onClick={checkAuth(onAddToWishlist)}
                  loading={isWishlistPending}
                >
                  <HeartIcon style={{ width: "24px", height: "24px" }} />
                  <Text variant="subtitle1" color="primary.400">
                    Favorite
                  </Text>
                </Button>
              </VisibleSection>
            </HStack>
          </VisibleSection>
        )}

        {isOutOfStock && (
          <>
            <Text color="red.500" fontWeight="semibold">
              This product is currently out of stock
            </Text>
            <Button
              variant="outline"
              width="170px"
              padding="10px 20px"
              onClick={() => router.push(ROUTES.APP.CONTACT_US)}
              loading={isWishlistPending}
            >
              <MailQuestion style={{ width: "24px", height: "24px" }} />
              <Text variant="subtitle1" color="primary.400">
                Inquire Now
              </Text>
            </Button>
          </>
        )}
      </VStack>

      <ProductDescription />
      <VisibleSection visibility={config?.cart_visibility}>
        <ProductReviews item_code={productDetail?.item_code ?? ""} />
      </VisibleSection>
    </Flex>
  );
};
