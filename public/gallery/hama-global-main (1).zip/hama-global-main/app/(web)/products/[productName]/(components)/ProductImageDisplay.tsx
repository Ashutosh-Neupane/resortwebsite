"use client";
import Image from "next/image";
import { useState } from "react";
import { Flex, Box, HStack, Text, VStack } from "@chakra-ui/react";

import { ProductImageDisplayProps } from "@/types";
import { useUserProfileQuery } from "@/hooks/api";

export const ProductImageDisplay: React.FC<ProductImageDisplayProps> = ({
  selectedImage,
  productName,
  productDetail,
}) => {
  const [hoverPosition, setHoverPosition] = useState({ x: 0, y: 0 });

  const isHovered = hoverPosition.x !== 0 || hoverPosition.y !== 0;

  const handleMouseMove = (e: React.MouseEvent) => {
    const { left, top, width, height } =
      e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setHoverPosition({ x, y });
  };

  const discountPercent = productDetail?.prices?.[0]?.custom_discount_;
  const { data: userProfileData } = useUserProfileQuery();
  return (
    <Flex
      justify="center"
      align="center"
      position={"relative"}
      py={{ base: 6, md: 10 }}
      px={{ base: 4, md: 8 }}
    >
      <Box
        position="relative"
        width="100%"
        maxW="500px"
        height="500px"
        overflow="hidden"
        borderRadius="2xl"
        boxShadow="xl"
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setHoverPosition({ x: 0, y: 0 })}
        bg="white"
      >
        {/* Discount Ribbon */}
        {discountPercent && Number(discountPercent) > 0 && userProfileData ? (
          <Box
            position="absolute"
            top=" -0.3rem"
            right="-3.2rem"
            width="162px"
            height="74px"
            bg="green.500"
            color="white"
            textAlign="center"
            lineHeight="1"
            fontSize="sm"
            fontWeight="bold"
            transform="rotate(45deg)"
            py={1}
            zIndex="1"
          >
            <HStack
              gap="0.6rem"
              align="center"
              position={"absolute"}
              top=" 2.4rem"
              dropShadow={"md"}
              right="3.4rem"
              rotate={"-45deg"}
            >
              <Box
                textShadow="9px 1px 3px #22c55e"
                css={{
                  WebkitTextStrokeWidth: "3px",
                  WebkitTextStrokeColor: "#22c55e",
                }}
                letterSpacing="-6px"
                fontSize="3.5rem"
              >
                {discountPercent}
              </Box>
              <VStack gap="0">
                <Text>%</Text>
                <Text>OFF</Text>
              </VStack>
            </HStack>
          </Box>
        ) : null}

        {selectedImage && (
          <Image
            src={selectedImage}
            alt={productName}
            width={500}
            height={500}
            style={{
              objectFit: "contain",
              width: "100%",
              height: "100%",
              transform: isHovered ? "scale(2)" : "scale(1)",
              transformOrigin: `${hoverPosition.x}% ${hoverPosition.y}%`,
              transition: "transform 0.4s ease",
            }}
            priority
          />
        )}
      </Box>
    </Flex>
  );
};
