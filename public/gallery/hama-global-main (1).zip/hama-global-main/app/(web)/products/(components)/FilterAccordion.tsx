"use client";
import {
  Box,
  Button,
  Grid,
  Heading,
  HStack,
  Input,
  Spinner,
  VStack,
} from "@chakra-ui/react";
import {
  AccordionItem,
  AccordionItemContent,
  CheckboxGroup,
  AccordionRoot,
  AccordionItemTrigger,
} from "@/components";
import { FilterAccordionProps } from "@/types";
import { useState, useMemo } from "react";
import { useFilterStore } from "@/store/products/filterStore";
import { FunnelIcon, FunnelX } from "lucide-react";

export const FilterAccordion = ({
  title,
  items,
  isFetching,
  name,
}: FilterAccordionProps) => {
  const [search, setSearch] = useState("");

  // Zustand store
  const { brand, item_group, setBrand, setItemGroup, setPage } =
    useFilterStore();

  const enableSearch = ["brands", "category"].includes(title.toLowerCase());

  const filteredItems = useMemo(() => {
    if (!enableSearch || !search) return items;
    return items.filter(({ title }) =>
      title.toLowerCase().includes(search.toLowerCase())
    );
  }, [items, search, enableSearch]);

  // Handle change synced with Zustand
  const handleCheckboxChange = (selected: string[]) => {
    const key = title.toLowerCase();

    if (key === "brands") {
      setBrand(selected);
    } else if (key === "category") {
      setItemGroup(selected);
    }

    setPage(1);
  };
  // Clear all selected items
  const handleClear = () => {
    if (title.toLowerCase() === "brands") {
      setBrand([]);
    } else if (
      title.toLowerCase() === "item_group" ||
      title.toLowerCase() === "category"
    ) {
      setItemGroup([]);
    }
    setPage(1); // Optionally reset pagination
  };

  // Determine which values to show as checked
  const selectedValues =
    title.toLowerCase() === "brands"
      ? brand
      : title.toLowerCase() === "category"
        ? item_group
        : [];

  return (
    <VStack>
      <AccordionRoot
        collapsible
        as={VStack}
        alignItems="stretch"
        defaultValue={[title]}
      >
        <AccordionItem value={title} border={"none"}>
          <HStack>
            <AccordionItemTrigger
              hasAccordionIcon
              isOpen
              cursor="pointer"
              outline={"none"}
            >
              <Heading variant="heading7">{title}</Heading>
            </AccordionItemTrigger>
            <Box>
              {(brand.length > 0 && title.toLowerCase() === "brands") ||
              (item_group.length > 0 &&
                (title.toLowerCase() === "item_group" ||
                  title.toLowerCase() === "category")) ? (
                <Box
                  as={Button}
                  onClick={handleClear}
                  fontSize={"sm"}
                  bg={"transparent"}
                  color={"green.500"}
                >
                  <FunnelX />
                </Box>
              ) : (
                <Box
                  as={Button}
                  fontSize="sm"
                  bg={"transparent"}
                  color={"green.500"}
                >
                  <FunnelIcon />
                </Box>
              )}
            </Box>
          </HStack>

          <AccordionItemContent>
            {isFetching ? (
              <Grid placeItems="center" height="120px">
                <Spinner />
              </Grid>
            ) : (
              <>
                {enableSearch && (
                  <Input
                    placeholder={`Search ${title.toLowerCase()}...`}
                    size="sm"
                    mb={2}
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                )}
                <Box maxH="350px" overflowY="auto" pr={2}>
                  <CheckboxGroup
                    name={name}
                    value={selectedValues}
                    onChange={handleCheckboxChange}
                    items={filteredItems.map(({ value, title }) => ({
                      value,
                      label: title,
                    }))}
                  />
                </Box>
              </>
            )}
          </AccordionItemContent>
        </AccordionItem>
      </AccordionRoot>
    </VStack>
  );
};
