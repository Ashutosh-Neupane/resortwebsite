"use client";
import { ROUTES } from "@/constants";
import { useShopNowPageQuery } from "@/hooks/api/(web)/shopNow";
import { Box, Flex, Heading, Text, Button, Container } from "@chakra-ui/react";
import { CheckCircle } from "lucide-react";
import { useRouter } from "next/navigation";

export const PromoBanner = () => {
  const { data: shopData } = useShopNowPageQuery();
  const router = useRouter();
  return (
    <Box
      position="relative"
      width="100%"
      height={{ base: "500px", md: "600px", lg: "700px" }}
      overflow="hidden"
    >
      <Box
        position="absolute"
        top={0}
        left={0}
        width="100%"
        height="100%"
        bgImage={`url(${shopData?.hero_image_link})`}
        bgSize="cover"
        bgPos="center"
        display="flex"
        alignItems="center"
        justifyContent="center"
        color="white"
        fontSize="xl"
        fontWeight="bold"
      ></Box>

      {/* Overlay */}
      <Box
        position="absolute"
        top={0}
        left={0}
        width="100%"
        height="100%"
        bg="rgba(0, 0, 0, 0.3)"
      />

      {/* Content */}
      <Container
        maxW="7xl"
        height="100%"
        position="relative"
        display="flex"
        alignItems="center"
      >
        <Flex
          direction="column"
          color="white"
          maxW={{ base: "100%", md: "60%", lg: "55%" }}
          gap={4}
          px={{ base: 4, md: 0 }}
        >
          <Heading
            as="h1"
            fontSize={{ base: "26px", sm: "46px", md: "56px" }}
            fontWeight="bold"
            lineHeight="1.2"
            maxW={{ base: "100%", lg: "55%" }}
            textShadow="0 2px 4px rgba(0,0,0,0.3)"
          >
            {shopData?.hero_title}
          </Heading>

          <Text
            fontSize={{ base: "20px", sm: "30px", md: "40px" }}
            fontWeight="medium"
            lineHeight="1.2"
            maxW={{ base: "100%", lg: "80%" }}
            mt={2}
            textShadow="0 1px 2px rgba(0,0,0,0.3)"
          >
            {shopData?.hero_description}
          </Text>
          <Box display="flex" flexDirection="column" gap={3} mb={6}>
            {shopData?.offers.map((item, index) => (
              <Box key={index} display="flex" alignItems="center" gap={2}>
                <CheckCircle color="green" size={18} />
                <Text fontSize={{ base: "sm", md: "18px" }}>{item.offer}</Text>
              </Box>
            ))}
          </Box>

          <Flex gap={4} direction={{ base: "column", sm: "row" }}>
            <Button
              color="white"
              bg="#16CA5E"
              borderRadius={"md"}
              alignSelf={{ base: "stretch", sm: "start" }}
              _hover={{ bg: "#14b955" }}
              zIndex={2}
              onClick={() => router.push(ROUTES.APP.PRODUCTS)}
            >
              Shop Now
            </Button>
          </Flex>
        </Flex>
      </Container>
    </Box>
  );
};
