"use client";
import Slider from "react-slick";
import {
  Box,
  Heading,
  VStack,
  IconButton,
  useBreakpointValue,
  Text,
  HStack,
} from "@chakra-ui/react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { ArrowLeftIcon, ArrowRightIcon } from "@/assets/svg";
import { ReactNode } from "react";
import { ProductSectionProps } from "@/types";
import { useProductSlider } from "@/hooks/app";
import { ProductCard } from "@/components";

// Custom Arrow Components
const NextArrow = ({ onClick }: { onClick: () => void }) => (
  <IconButton
    aria-label="Next"
    onClick={onClick}
    position="absolute"
    right="-16px"
    bottom={{ base: "-10%", md: "-16%" }}
    transform="translateY(-50%)"
    zIndex={2}
    bg="gray.200"
    _hover={{ bg: "gray.300" }}
    borderRadius="full"
  >
    <ArrowRightIcon />
  </IconButton>
);

const PrevArrow = ({ onClick }: { onClick: () => void }) => (
  <IconButton
    aria-label="Prev"
    onClick={onClick}
    position="absolute"
    right="32px"
    bottom={{ base: "-10%", md: "-16%" }}
    transform="translateY(-50%)"
    zIndex={2}
    bg="gray.200"
    _hover={{ bg: "gray.300" }}
    borderRadius="full"
  >
    <ArrowLeftIcon />
  </IconButton>
);

export const FeatureProducts = ({ type }: ProductSectionProps) => {
  const { sectionData } = useProductSlider(type);

  const { title, subtitle, products } = sectionData;

  const slidesToShow = useBreakpointValue({
    base: 1,
    sm: 2,
    md: 2,
    lg: 4,
    xl: 4,
  });

  const settings = {
    dots: true,
    arrows: true,
    infinite: true,
    speed: 500,
    slidesToShow: slidesToShow || 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    nextArrow: <NextArrow onClick={() => {}} />,
    prevArrow: <PrevArrow onClick={() => {}} />,
    appendDots: (dots: ReactNode) => (
      <Box mt={8}>
        <ul style={{ position: "absolute", bottom: "-12%", left: "2%" }}>
          {dots}
        </ul>
      </Box>
    ),
  };

  return (
    <Box
      maxW={"7xl"}
      mx="auto"
      position="relative"
      py={{ base: 10, md: 20 }}
      px={{ base: 4, md: 8 }}
    >
      <HStack justifyContent="space-between">
        <VStack alignItems="start" gap={{ base: "0", md: "8px" }}>
          <Heading fontSize={{ base: "20px", lg: "24px", xl: "28px" }}>
            {title}
          </Heading>
          <Text
            variant={{ base: "paragraphSmall", md: "paragraphRegular" }}
            color="system.text.normal.light"
          >
            {subtitle}
          </Text>
        </VStack>
      </HStack>

      <Box position="relative">
        <Slider {...settings}>
          {products.map((productInfo) => {
            return (
              <>
                <Box p={1} my={4} bg="white" mx={2}>
                  <ProductCard {...productInfo} />
                </Box>
                {/* <Box
                  borderWidth="1px"
                  borderRadius="xl"
                  p={4}
                  my={4}
                  bg="white"
                  mx={2}
                   cursor="pointer"
                        onClick={() =>
                          router.push(
                            generateNextPath(ROUTES.APP.INDIVIDUAL_PRODUCT, {
                              productName: productInfo.title,
                            })
                          )
                        }
                >
                  <Image
                    src={productInfo.image}
                    alt={productInfo.title}
                    borderRadius="md"
                    objectFit="cover"
                    boxSize="300px"
                    mx="auto"
                    mb={4}
                  />

                  <VStack gap={2} align="stretch" textAlign="center">
                    <Flex
                      gap={2}
                      justifyContent={"space-between"}
                      align="center"
                    >
                      <Text fontSize="lg" fontWeight="semibold">
                        {productInfo.title}
                      </Text>
                      <Text fontSize="md" color="green.500" fontWeight="bold">
                        ${productInfo.price}
                      </Text>
                    </Flex>

                    <Button
                      bg={"#16CA5E"}
                      variant="solid"
                      size="sm"
                      mt={2}
                      _hover={{ cursor: "pointer" }}
                    >
                      Add to Cart
                    </Button>
                  </VStack>
                </Box> */}
              </>
            );
          })}
        </Slider>
      </Box>
    </Box>
  );
};
