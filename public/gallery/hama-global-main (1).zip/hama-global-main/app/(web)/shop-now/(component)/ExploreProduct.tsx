"use client";
import { useShopNowPageQuery } from "@/hooks/api/(web)/shopNow";
import { ROUTES } from "@/constants";
import { Box, Button, Heading, Stack, Text } from "@chakra-ui/react";
import { useRouter } from "next/navigation";

export const ExploreProduct = () => {
  const { data: shopData } = useShopNowPageQuery();
  const router = useRouter();

  return (
    <Box
      maxW={"8xl"}
      mx={"auto"}
      px={{ base: 4, md: 8, lg: 8 }}
      py={{ base: 6, md: 16, xl: 16 }}
      bgImage={`url(${shopData?.footer_image_link})`}
      bgPos="bottom"
      bgRepeat="no-repeat"
      bgSize="cover"
      position="relative"
    >
      {/* Dark overlay */}
      <Box
        position="absolute"
        top={0}
        left={0}
        right={0}
        bottom={0}
        bg="rgba(56, 55, 55, 0.50)"
        zIndex={1}
      />

      {/* Content */}
      <Stack
        maxW={"7xl"}
        px={{ base: 4, md: 6, lg: 8 }}
        pt={{ base: 6, md: 10, xl: 20 }}
        pb={{ base: 6, md: 10, xl: 20 }}
        flex="1"
        gap={4}
        position="relative"
        zIndex={2}
      >
        <Heading
          fontSize={{ base: "36px", md: "36px", lg: "48px" }}
          fontWeight="semibold"
          color="white"
          lineHeight="1.1"
          textAlign={"center"}
        >
          {shopData?.footer_title}
        </Heading>
        <Text
          fontSize={{ base: "16px", md: "18px" }}
          color="white"
          width={"90%"}
        >
          {shopData?.footer_description}
        </Text>
        <Button
          color="white"
          bg="#16CA5E"
          variant={"solid"}
          borderRadius={"md"}
          py={{ base: 2, md: 2 }}
          alignSelf={{ base: "stretch", sm: "center" }}
          onClick={() => router.push(ROUTES.APP.PRODUCTS)}
          _hover={{ bg: "#16ca5eba" }}
          zIndex={2}
        >
          Our Products
        </Button>
      </Stack>
    </Box>
  );
};
