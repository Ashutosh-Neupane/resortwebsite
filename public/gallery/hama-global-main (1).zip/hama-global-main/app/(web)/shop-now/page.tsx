import { ExploreProduct } from "./(component)/ExploreProduct";
import { FeatureProducts } from "./(component)/FeatureProducts";
import { PromoBanner } from "./(component)/PromoBanner";

const ShopNow = () => {
  return (
    <>
      <PromoBanner />
      <FeatureProducts type="bestSellers" />
      <ExploreProduct />
    </>
  );
};

export default ShopNow;
