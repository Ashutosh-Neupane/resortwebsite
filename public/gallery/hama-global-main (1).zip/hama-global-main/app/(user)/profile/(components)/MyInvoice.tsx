"use client";

import * as React from "react";
import Image from "next/image";
import {
  Badge,
  Box,
  Flex,
  Grid,
  HStack,
  Span,
  Spinner,
  Stack,
  Text,
  VStack,
} from "@chakra-ui/react";

import { EmptyStateImage } from "@/assets/image";
import { Button } from "@/components";
import { useConfigQuery, useInvoiceListQuery } from "@/hooks/api";
import { useCheckoutStore } from "@/store/products/checkoutStore";
import { useRouter } from "next/navigation";
import { Invoice } from "@/types";
import { Dialog } from "@/components/ui/dialog";
import { Eye } from "lucide-react";

export const MyInvoice = () => {
  const { data: invoiceData, isLoading } = useInvoiceListQuery();
  const { data: config } = useConfigQuery();
  const router = useRouter();
  const setCheckoutData = useCheckoutStore((state) => state.setCheckoutData);
  const [selectedInvoice, setSelectedInvoice] = React.useState<Invoice | null>(
    null
  );

  const handlePayNow = (invoiceData: Invoice) => {
    if (invoiceData) {
      setCheckoutData({
        customer: invoiceData.customer,
        order_id: invoiceData.order_id,
        description: invoiceData.description,
        amount: invoiceData.amount,
        currency: invoiceData.currency,
        returnurl: invoiceData.returnurl,
        cancelurl: invoiceData.cancelurl,
      });

      router.push("/checkout");
    }
  };

  const handleViewOrderItems = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
  };

  const handleCloseDialog = () => {
    setSelectedInvoice(null);
  };

  return (
    <Box
      flex="1"
      borderRadius="16px"
      p="20px"
      border="1px solid"
      borderColor="gray.200"
    >
      <Text variant="subtitle1" mb={4}>
        My Invoice
      </Text>

      {isLoading ? (
        <Box textAlign="center">
          <Spinner />
          <Text mt={4} variant="paragraphRegular">
            Loading your invioce...
          </Text>
        </Box>
      ) : invoiceData?.length === 0 ? (
        <Box textAlign="center" placeItems={"center"}>
          <Image
            src={EmptyStateImage}
            alt="Empty State"
            width={304}
            height={272}
          />
          <Grid>
            <Text mt={4} variant="subtitle1">
              No Items!
            </Text>
            <Text variant="paragraphRegular" color="primary.300">
              Looks like you haven’t generated any invoices yet.
            </Text>
          </Grid>
        </Box>
      ) : (
        <>
          {/* Desktop View (lg) */}
          <Box display={{ base: "none", md: "none", lg: "block" }}>
            <HStack
              px={4}
              py={2}
              borderBottom="1px solid"
              borderColor="gray.300"
              fontWeight="bold"
            >
              <Text flex="1.5">Invoice Id</Text>

              <Text flex="1" textAlign="center">
                Invoice Date
              </Text>
              {/* <Text flex="1" textAlign="center">
                Invoice Status
              </Text> */}
              <Text flex="1" textAlign="center">
                Grand Total
              </Text>
              <Text flex="1" textAlign="center">
                Outstanding
              </Text>
              <Text flex="1" textAlign="left">
                Payment Status
              </Text>
              <Text flex="1" textAlign="center">
                View Invoice
              </Text>
            </HStack>

            <Stack gap={4} mt={2}>
              {invoiceData?.map((item, index) => (
                <HStack
                  key={index}
                  px={4}
                  py={3}
                  borderBottom={
                    index === invoiceData.length - 1 ? "none" : "1px solid"
                  }
                  borderColor="gray.200"
                  alignItems="center"
                >
                  <HStack flex="1.5" gap={4}>
                    <Image
                      src={config.company_details_url}
                      alt={config.company_details_name}
                      width={50}
                      height={50}
                    />
                    <Stack gap={0}>
                      <Text
                        variant="paragraphSmall"
                        cursor="pointer"
                        textDecoration={"underline"}
                        onClick={() => handleViewOrderItems(item)}
                      >
                        {item.name}
                      </Text>
                    </Stack>
                  </HStack>

                  <Text flex="1" textAlign="center" variant="paragraphSmall">
                    {item.posting_date}
                  </Text>
                  {/* <Text flex="1" textAlign="center" variant="paragraphSmall">
                    <Badge
                      style={{
                        fontSize: "0.90rem",
                        backgroundColor:
                          item.status === "Pending" ? "orange" : "gray",
                        color: "white",
                      }}
                    >
                      {item.status}
                    </Badge>
                  </Text> */}
                  <Text
                    flex="1"
                    textAlign="center"
                    ml={2}
                    variant="paragraphSmall"
                  >
                    {config.currency} {item.grand_total}
                  </Text>
                  <Text
                    flex="1"
                    textAlign="center"
                    ml={2}
                    variant="paragraphSmall"
                  >
                    {config.currency} {item.outstanding_amount}
                  </Text>
                  <Flex flex="1" justify="left" align="center" gap={4}>
                    <Badge
                      style={{ fontSize: "0.90rem" }}
                      variant={
                        item.payment_status === "Pending"
                          ? "solid"
                          : item.payment_status === "Fully Paid"
                            ? "primary"
                            : "subtle"
                      }
                      color={
                        item.payment_status === "Pending"
                          ? "red"
                          : item.payment_status === "Fully Paid"
                            ? "green"
                            : "orange"
                      }
                    >
                      {item.payment_status}
                    </Badge>
                    {item.payment_status !== "Fully Paid" && (
                      <Button
                        borderRadius={5}
                        paddingY={0}
                        paddingX={2}
                        height={"10px"}
                        bg={"green.500"}
                        onClick={() => handlePayNow(item)}
                      >
                        Pay Now
                      </Button>
                    )}
                  </Flex>
                  <Box
                    display={"flex"}
                    cursor={"pointer"}
                    flex="1"
                    justifyContent="center"
                    onClick={() => window.open(item.pdf_url, "_blank")}
                  >
                    <Eye />
                  </Box>
                </HStack>
              ))}
            </Stack>
          </Box>
          {/* Mobile View (base) */}
          <Box display={{ base: "block", md: "block", lg: "none" }}>
            <Stack gap={4}>
              {invoiceData?.map((item, index) => (
                <VStack
                  key={index}
                  p={4}
                  border="1px solid"
                  borderColor="gray.200"
                  borderRadius="8px"
                  align="stretch"
                  gap={3}
                >
                  <HStack align="flex-start">
                    <Image
                      src={config.company_details_url}
                      alt={config.company_details_name}
                      width={50}
                      height={50}
                    />
                    <Box>
                      <Text
                        fontWeight="bold"
                        cursor="pointer"
                        _hover={{ textDecoration: "underline" }}
                        onClick={() => handleViewOrderItems(item)}
                      >
                        {item.name}
                      </Text>
                      <Text variant="paragraphSmall">{item.posting_date}</Text>
                    </Box>
                  </HStack>

                  {/* <HStack justify="space-between">
                    <Text variant="paragraphSmall">Invoice Status:</Text>
                    <Badge
                      style={{
                        fontSize: "0.90rem",
                        backgroundColor:
                          item.status === "Pending" ? "orange" : "gray",
                        color: "white",
                      }}
                    >
                      {item.status}
                    </Badge>
                  </HStack> */}

                  <HStack justify="space-between">
                    <Text variant="paragraphSmall">Grand Total:</Text>
                    <Text variant="paragraphSmall">
                      {config.currency} {item.grand_total}
                    </Text>
                  </HStack>
                  <HStack justify="space-between">
                    <Text variant="paragraphSmall">Outstanding Amount:</Text>
                    <Text variant="paragraphSmall">
                      {config.currency} {item.outstanding_amount}
                    </Text>
                  </HStack>

                  <HStack justify="space-between">
                    <Text variant="paragraphSmall">Payment Status:</Text>
                    <HStack>
                      <Badge
                        style={{ fontSize: "0.90rem" }}
                        variant={
                          item.payment_status === "Pending"
                            ? "solid"
                            : item.payment_status === "Paid"
                              ? "subtle"
                              : "primary"
                        }
                        color={
                          item.payment_status === "Pending"
                            ? "red"
                            : item.payment_status === "Fully Paid"
                              ? "green"
                              : "orange"
                        }
                      >
                        {item.payment_status}
                      </Badge>
                      {item.payment_status !== "Fully Paid" && (
                        <Button
                          paddingY={0}
                          paddingX={2}
                          borderRadius={5}
                          bg={"green.500"}
                          onClick={() => handlePayNow(item)}
                        >
                          Pay Now
                        </Button>
                      )}
                    </HStack>
                  </HStack>
                  <Button
                    bg={"#16CA5E"}
                    borderRadius={"2rem"}
                    onClick={() => window.open(item.pdf_url, "_blank")}
                  >
                    View Invoice
                  </Button>
                </VStack>
              ))}
            </Stack>
          </Box>

          {/* Order Items Dialog */}
          <Dialog
            open={!!selectedInvoice}
            onClose={handleCloseDialog}
            title={`Order Details - ${selectedInvoice?.name}`}
            hasCloseTrigger={true}
            size={{ base: "sm", md: "xl" }}
            // contentMinWidth="600px"
          >
            {selectedInvoice && (
              <Box p={8} borderRadius={8}>
                <VStack px={4} gap={4} align="stretch">
                  <Box>
                    <Text fontWeight="bold">Order Information</Text>
                    <Text>Date: {selectedInvoice.posting_date}</Text>
                    <Text>Status: {selectedInvoice.status}</Text>
                    <Text>
                      Total<Span fontSize="10px">(*included Tax)</Span>:{" "}
                      {config?.currency} {selectedInvoice.grand_total}
                    </Text>
                    <Text>
                      Payment Status: {selectedInvoice.payment_status}
                    </Text>
                  </Box>
                  <Box>
                    <Text fontWeight="bold" mb={2}>
                      Items
                    </Text>
                    <Stack gap={3}>
                      {selectedInvoice.items?.map((item, index) => (
                        <Box
                          key={index}
                          p={3}
                          border="1px solid"
                          borderColor="gray.200"
                          borderRadius="md"
                        >
                          <HStack align="flex-start" gap={4}>
                            {item.image_url && (
                              <Image
                                src={
                                  item.image_url || config?.company_details_url
                                }
                                alt={item.item_name}
                                width={80}
                                height={80}
                                objectFit="cover"
                              />
                            )}

                            <Box flex={1}>
                              <HStack justify="space-between">
                                <Text fontWeight="medium">
                                  {item.item_name}
                                </Text>
                                <Text>
                                  {config?.currency} {item.amount}
                                </Text>
                              </HStack>
                              <Text>Quantity: {item.qty}</Text>
                              {item.rate && (
                                <Text>
                                  Rate: {config?.currency} {item.rate}
                                </Text>
                              )}
                            </Box>
                          </HStack>
                        </Box>
                      ))}
                    </Stack>
                  </Box>
                </VStack>
              </Box>
            )}
          </Dialog>
        </>
      )}
    </Box>
  );
};
