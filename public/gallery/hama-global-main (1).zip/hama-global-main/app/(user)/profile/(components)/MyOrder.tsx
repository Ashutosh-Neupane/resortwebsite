"use client";

import * as React from "react";
import Image from "next/image";
import {
  Badge,
  Box,
  Flex,
  Grid,
  HStack,
  Span,
  Spinner,
  Stack,
  Text,
  VStack,
} from "@chakra-ui/react";

import { EmptyStateImage } from "@/assets/image";
import { Button } from "@/components";
import { useConfigQuery, useOrderListQuery } from "@/hooks/api";
import { useCheckoutStore } from "@/store/products/checkoutStore";
import { useRouter } from "next/navigation";
import { OrderType } from "@/types";
import { Dialog } from "@/components/ui/dialog";

export const MyOrder = () => {
  const { data: orderData, isLoading } = useOrderListQuery();
  const { data: config } = useConfigQuery();
  const router = useRouter();
  const setCheckoutData = useCheckoutStore((state) => state.setCheckoutData);
  const [selectedOrder, setSelectedOrder] = React.useState<OrderType | null>(
    null
  );

  const handlePayNow = (orderData: OrderType) => {
    if (orderData) {
      setCheckoutData({
        customer: orderData.customer,
        order_id: orderData.name,
        description: orderData.description,
        amount: orderData.amount,
        currency: orderData.currency,
        returnurl: orderData.returnurl,
        cancelurl: orderData.cancelurl,
      });

      router.push("/checkout");
    }
  };

  const handleViewOrderItems = (order: OrderType) => {
    setSelectedOrder(order);
  };

  const handleCloseDialog = () => {
    setSelectedOrder(null);
  };

  return (
    <Box
      flex="1"
      borderRadius="16px"
      p="20px"
      border="1px solid"
      borderColor="gray.200"
    >
      <Text variant="subtitle1" mb={4}>
        My Order
      </Text>

      {isLoading ? (
        <Box textAlign="center">
          <Spinner />
          <Text mt={4} variant="paragraphRegular">
            Loading your order...
          </Text>
        </Box>
      ) : orderData?.length === 0 ? (
        <Box textAlign="center" placeItems={"center"}>
          <Image
            src={EmptyStateImage}
            alt="Empty State"
            width={304}
            height={272}
          />
          <Grid>
            <Text mt={4} variant="subtitle1">
              No Items!
            </Text>
            <Text variant="paragraphRegular" color="primary.300">
              It seems you have not added anything to your cart yet.
            </Text>
          </Grid>
        </Box>
      ) : (
        <>
          {/* Desktop View (lg) */}
          <Box display={{ base: "none", md: "none", lg: "block" }}>
            <HStack
              px={4}
              py={2}
              borderBottom="1px solid"
              borderColor="gray.300"
              fontWeight="bold"
            >
              <Text flex="2">Order Name</Text>

              <Text flex="1" textAlign="left">
                Order Date
              </Text>
              <Text flex="1" textAlign="left">
                Order Status
              </Text>
              <Text flex="1" textAlign="left">
                Grand Total
              </Text>
              <Text flex="1" textAlign="left">
                Payment Status
              </Text>
            </HStack>

            <Stack gap={4} mt={2}>
              {orderData?.map((item, index) => (
                <HStack
                  key={index}
                  px={4}
                  py={3}
                  borderBottom={
                    index === orderData.length - 1 ? "none" : "1px solid"
                  }
                  borderColor="gray.200"
                  alignItems="center"
                >
                  <HStack flex="2" gap={4}>
                    <Image
                      src={config.company_details_url}
                      alt={config.company_details_name}
                      width={50}
                      height={50}
                    />
                    <Stack gap={0}>
                      <Text
                        variant="paragraphSmall"
                        cursor="pointer"
                        textDecoration={"underline"}
                        onClick={() => handleViewOrderItems(item)}
                      >
                        {item.name}
                      </Text>
                    </Stack>
                  </HStack>

                  <Text flex="1" textAlign="left" variant="paragraphSmall">
                    {item.transaction_date}
                  </Text>
                  <Text flex="1" textAlign="left" variant="paragraphSmall">
                    <Badge
                      variant="primary"
                      color={"green"}
                      style={{ fontSize: "0.90rem" }}
                    >
                      {item.status}
                    </Badge>
                  </Text>
                  <Text flex="1" textAlign="left" variant="paragraphSmall">
                    {config.currency} {item.grand_total}
                  </Text>
                  <Flex flex="1" justify="left" align="center" gap={4}>
                    <Badge
                      style={{ fontSize: "0.90rem" }}
                      variant={
                        item.payment_status === "Pending"
                          ? "solid"
                          : item.payment_status === "Paid"
                            ? "subtle"
                            : "primary"
                      }
                      color={
                        item.payment_status === "Pending"
                          ? "red"
                          : item.payment_status === "Paid"
                            ? "green"
                            : "orange"
                      }
                    >
                      {item.payment_status}
                    </Badge>
                    {item.payment_status === "Pending" && (
                      <Button
                        borderRadius={5}
                        paddingY={0}
                        paddingX={2}
                        height={"10px"}
                        bg={"green.500"}
                        onClick={() => handlePayNow(item)}
                      >
                        Pay Now
                      </Button>
                    )}
                  </Flex>
                </HStack>
              ))}
            </Stack>
          </Box>

          {/* Tablet View (md) */}
          {/* <Box display={{ base: "none", md: "block", lg: "none" }}>
            <HStack
              px={4}
              py={2}
              borderBottom="1px solid"
              borderColor="gray.300"
              fontWeight="bold"
            >
              <Text flex="2">Order Name</Text>
              <Text flex="1" textAlign="center">
                Price
              </Text>
              <Text flex="1" textAlign="start">
                Order Date
              </Text>
              <Text flex="1" textAlign="center">
                Payment Status
              </Text>
            </HStack>

            <Stack gap={4} mt={2}>
              {orderData?.map((item, index) => (
                <HStack
                  key={index}
                  px={4}
                  py={3}
                  borderBottom={
                    index === orderData.length - 1 ? "none" : "1px solid"
                  }
                  borderColor="gray.200"
                  alignItems="center"
                >
                  <HStack flex="2" gap={4}>
                    <Image
                      src={config.company_details_url}
                      alt={config.company_details_name}
                      width={50}
                      height={50}
                    />
                    <Stack gap={0}>
                      <Text variant="paragraphSmall">{item.name}</Text>
                    </Stack>
                  </HStack>

                  <Text flex="1" textAlign="right" variant="paragraphSmall">
                    {config.currency} {item.grand_total}
                  </Text>
                  <Text flex="1" textAlign="right" variant="paragraphSmall">
                    {item.transaction_date}
                  </Text>
                  <Flex flex="1" justify="flex-end" align="center" gap={4}>
                    <Badge
                      variant={
                        item.payment_status === "Pending" ? "solid" : "primary"
                      }
                    >
                      {item.payment_status}
                    </Badge>
                    {item.payment_status !== "Paid" && (
                      <Button
                        borderRadius={3}
                        onClick={() =>
                          (window.location.href = item.payment_url)
                        }
                      >
                        Pay Now
                      </Button>
                    )}
                  </Flex>
                </HStack>
              ))}
            </Stack>
          </Box> */}

          {/* Mobile View (base) */}
          {/* <Box display={{ base: "block", md: "none", lg: "none" }}>
            <Stack gap={4}>
              {orderData?.map((item, index) => (
                <VStack
                  key={index}
                  p={4}
                  border="1px solid"
                  borderColor="gray.200"
                  borderRadius="8px"
                  align="stretch"
                >
                  <HStack>
                    <Image
                      src={config.company_details_url}
                      alt={config.company_details_name}
                      width={50}
                      height={50}
                    />
                    <Text>{item.name}</Text>
                  </HStack>

                  <Text variant="paragraphSmall">
                    <strong>Price:</strong> {config.currency} {item.grand_total}
                  </Text>
                  <Text variant="paragraphSmall">
                    <strong>Order Date:</strong> {item.transaction_date}
                  </Text>
                  <HStack justify="space-between">
                    <Badge
                      variant={
                        item.payment_status === "Pending" ? "solid" : "primary"
                      }
                    >
                      {item.payment_status}
                    </Badge>
                    {item.payment_status !== "Paid" && (
                      <Button
                        size="sm"
                        onClick={() =>
                          (window.location.href = item.payment_url)
                        }
                      >
                        Pay Now
                      </Button>
                    )}
                  </HStack>
                </VStack>
              ))}
            </Stack>
          </Box> */}
          {/* Mobile View (base) */}
          <Box display={{ base: "block", md: "block", lg: "none" }}>
            <Stack gap={4}>
              {orderData?.map((item, index) => (
                <VStack
                  key={index}
                  p={4}
                  border="1px solid"
                  borderColor="gray.200"
                  borderRadius="8px"
                  align="stretch"
                  gap={3}
                >
                  <HStack align="flex-start">
                    <Image
                      src={config.company_details_url}
                      alt={config.company_details_name}
                      width={50}
                      height={50}
                    />
                    <Box>
                      <Text
                        fontWeight="bold"
                        cursor="pointer"
                        _hover={{ textDecoration: "underline" }}
                        onClick={() => handleViewOrderItems(item)}
                      >
                        {item.name}
                      </Text>
                      <Text variant="paragraphSmall">
                        {item.transaction_date}
                      </Text>
                    </Box>
                  </HStack>

                  <HStack justify="space-between">
                    <Text variant="paragraphSmall">Order Status:</Text>
                    <Badge
                      variant="primary"
                      color={"green"}
                      style={{ fontSize: "0.90rem" }}
                    >
                      {item.status}
                    </Badge>
                  </HStack>

                  <HStack justify="space-between">
                    <Text variant="paragraphSmall">Grand Total:</Text>
                    <Text variant="paragraphSmall">
                      {config.currency} {item.grand_total}
                    </Text>
                  </HStack>

                  <HStack justify="space-between">
                    <Text variant="paragraphSmall">Payment Status:</Text>
                    <HStack>
                      <Badge
                        style={{ fontSize: "0.90rem" }}
                        variant={
                          item.payment_status === "Pending"
                            ? "solid"
                            : item.payment_status === "Paid"
                              ? "subtle"
                              : "primary"
                        }
                        color={
                          item.payment_status === "Pending"
                            ? "red"
                            : item.payment_status === "Paid"
                              ? "green"
                              : "orange"
                        }
                      >
                        {item.payment_status}
                      </Badge>
                      {item.payment_status === "Pending" && (
                        <Button
                          paddingY={0}
                          paddingX={2}
                          borderRadius={5}
                          bg={"green.500"}
                          onClick={() => handlePayNow(item)}
                        >
                          Pay Now
                        </Button>
                      )}
                    </HStack>
                  </HStack>
                </VStack>
              ))}
            </Stack>
          </Box>

          {/* Order Items Dialog */}
          <Dialog
            open={!!selectedOrder}
            onClose={handleCloseDialog}
            title={`Order Details - ${selectedOrder?.name}`}
            hasCloseTrigger={true}
            size={{ base: "sm", md: "xl" }}
            // contentMinWidth="600px"
          >
            {selectedOrder && (
              <Box p={8} borderRadius={8}>
                <VStack px={4} gap={4} align="stretch">
                  <Box>
                    <Text fontWeight="bold">Order Information</Text>
                    <Text>Date: {selectedOrder.transaction_date}</Text>
                    <Text>Status: {selectedOrder.status}</Text>
                    <Text>
                      Total<Span fontSize="10px">(*included Tax)</Span>:{" "}
                      {config?.currency} {selectedOrder.grand_total}
                    </Text>
                    <Text>Payment Status: {selectedOrder.payment_status}</Text>
                  </Box>
                  <Box>
                    <Text fontWeight="bold" mb={2}>
                      Items
                    </Text>
                    <Stack gap={3}>
                      {selectedOrder.items?.map((item, index) => (
                        <Box
                          key={index}
                          p={3}
                          border="1px solid"
                          borderColor="gray.200"
                          borderRadius="md"
                        >
                          <HStack align="flex-start" gap={4}>
                            {item.image_url && (
                              <Image
                                src={
                                  item.image_url || config?.company_details_url
                                }
                                alt={item.item_name}
                                width={80}
                                height={80}
                                objectFit="cover"
                              />
                            )}

                            <Box flex={1}>
                              <HStack justify="space-between">
                                <Text fontWeight="medium">
                                  {item.item_name}
                                </Text>
                                <Text>
                                  {config?.currency} {item.amount}
                                </Text>
                              </HStack>
                              <Text>Quantity: {item.qty}</Text>
                              {item.rate && (
                                <Text>
                                  Rate: {config?.currency} {item.rate}
                                </Text>
                              )}
                            </Box>
                          </HStack>
                        </Box>
                      ))}
                    </Stack>
                  </Box>
                </VStack>
              </Box>
            )}
          </Dialog>
        </>
      )}
    </Box>
  );
};
