"use client";
import { PageTitle } from "@/components";
import { BREADCRUMB_CONFIG } from "@/config";
import { ROUTES } from "@/constants";

import { MyOrder } from "./(components)";
import { Box, Flex, Heading, Tabs, Text } from "@chakra-ui/react";
import { Profile } from "@/assets/svg";
import {
  useInvoiceListQuery,
  useOrderListQuery,
  useUserProfileQuery,
} from "@/hooks/api";
import { MyInvoice } from "./(components)/MyInvoice";
import { ReceiptText, ShoppingCartIcon } from "lucide-react";

const UserProfile = () => {
  const { data: profileData } = useUserProfileQuery();
  const { data: invoiceData } = useInvoiceListQuery();
  const { data: orderData } = useOrderListQuery();

  return (
    <>
      <Box minH={"100dvh"}>
        <PageTitle
          backLabel="Back to homepage"
          backLink={ROUTES.APP.HOMEPAGE}
          title="Profile"
          breadcrumb={BREADCRUMB_CONFIG.PROFILE}
        />

        {/* <ProfileDetails /> */}
        <Box mt={6} maxWidth="7xl" mx="auto" px={{ base: "20px", md: "6" }}>
          <Flex align="center" gap={4}>
            {/* Icon on the left */}
            <Box boxSize="50px">
              <Profile width="100%" height="100%" />
            </Box>

            {/* Name and user info stacked vertically */}
            <Flex direction="column">
              <Heading variant="heading5">{profileData?.customer_name}</Heading>
              {profileData?.user && (
                <>
                  <Text fontSize="sm" color="gray.600" mt={1}>
                    {profileData.user}
                  </Text>
                  <Text fontSize="sm" color="gray.600" mt={1}>
                    {profileData.custom_customer_contact}
                  </Text>
                </>
              )}
            </Flex>
          </Flex>
        </Box>

        {/* <CartWishlistSection />
        <MyInvoice /> */}
        <Box mt={10} maxWidth="7xl" mx="auto" px={{ base: "20px", md: "6" }}>
          <Tabs.Root defaultValue="order">
            <Tabs.List>
              <Tabs.Trigger value="order">
                <ShoppingCartIcon />
                My Order
                {orderData && orderData.length > 0 && (
                  <Box
                    position="absolute"
                    top="0"
                    right="0"
                    bg="red.500"
                    color="white"
                    fontSize="8px"
                    borderRadius="full"
                    w="3.5"
                    h="3.5"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                  >
                    {orderData?.length}
                  </Box>
                )}
              </Tabs.Trigger>
              <Tabs.Trigger value="invoice">
                <ReceiptText />
                My Invoice{" "}
                {invoiceData && invoiceData.length > 0 && (
                  <Box
                    position="absolute"
                    top="0"
                    right="0"
                    bg="red.500"
                    color="white"
                    fontSize="8px"
                    borderRadius="full"
                    w="3.5"
                    h="3.5"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                  >
                    {invoiceData?.length}
                  </Box>
                )}
              </Tabs.Trigger>
            </Tabs.List>
            <Tabs.Content value="order">
              <MyOrder />
            </Tabs.Content>
            <Tabs.Content value="invoice">
              <MyInvoice />
            </Tabs.Content>
          </Tabs.Root>
        </Box>
      </Box>
    </>
  );
};

export default UserProfile;
