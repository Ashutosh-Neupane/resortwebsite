"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

import {
  Box,
  Button,
  Flex,
  Heading,
  HStack,
  Stack,
  Text,
  VStack,
} from "@chakra-ui/react";
import { ColumnDef } from "@tanstack/react-table";

import {
  CartDeleteButton,
  Checkbox,
  QuantityInput,
  TableWithCheckbox,
} from "@/components";
import { ROUTES } from "@/constants";
import {
  useAddPromo,
  useCartMutationNew,
  useCartQuery,
  useConfigQuery,
  useDeliveryChargesQuery,
} from "@/hooks/api";
import { useRemoveFromCart } from "@/hooks/app";
import { useItemStore, usePromoFormStore, usePromoStore } from "@/store";
import { ProductDetail, PromoFormData } from "@/types";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";

interface CartSummaryProps {
  onQuantityChange: (newQuantity: boolean) => void;
}

export const CartSummary = ({ onQuantityChange }: CartSummaryProps) => {
  const router = useRouter();
  const queryClient = useQueryClient();
  const methods = useForm<PromoFormData>();

  const { data: config } = useConfigQuery();
  const { data: cartData } = useCartQuery();
  const { data: deliveryData } = useDeliveryChargesQuery();

  const { items: originalItems, setItems } = useItemStore();
  const { resetPromoForm } = usePromoFormStore();

  const { mutate: handleAddToCartNew } = useCartMutationNew();
  const { mutate: applyPromo } = useAddPromo();

  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [localItems, setLocalItems] = useState<ProductDetail[]>([]);
  const [hasPendingChanges, setHasPendingChanges] = useState(false);
  // for the first time, set the delivery location to the first one in the list start
  const deliveryLocation = methods.watch("deliveryLocation");
  const delivery =
    deliveryLocation ||
    (Array.isArray(deliveryData) && deliveryData.length > 0
      ? deliveryData[0].name1
      : "");
  // for the first time, set the delivery location to the first one in the list end

  const { setPromoData } = usePromoStore();

  const { handleRemoveFromCart, isPending: isRemovingFromCart } =
    useRemoveFromCart({
      items: originalItems,
      selectedItems,
      setSelectedItems,
    });

  useEffect(() => {
    if (cartData) {
      setItems(cartData);
      setLocalItems(cartData);
    }
    applyPromo(
      {
        coupon: "",
        delivery_charge: delivery,
        online_payment_choosed: 0,
        bsb_choosed: 0,
      },
      {
        onSuccess: (res) => {
          setPromoData(res.data.data);
        },
        onError: () => {},
      }
    );
  }, [cartData, applyPromo, setItems, setPromoData]);

  const handleQuantityChange = (id: string, newQuantity: number) => {
    setLocalItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, quantity: newQuantity } : item
      )
    );
    setHasPendingChanges(true);
    onQuantityChange(true);
  };

  const handleApplyChanges = () => {
    if (!hasPendingChanges) return;

    const changes: { item_code: string; quantity: number }[] = [];

    localItems.forEach((localItem) => {
      const originalItem = originalItems.find(
        (item) => item.id === localItem.id
      );
      if (originalItem && localItem.quantity !== originalItem.quantity) {
        changes.push({
          item_code: localItem.title,
          quantity: localItem.quantity,
        });
      }
    });

    if (changes.length > 0) {
      changes.forEach((change) => {
        handleAddToCartNew(change, {
          onSuccess: () => {
            resetPromoForm();
            applyPromo(
              {
                coupon: "",
                delivery_charge: delivery,
                online_payment_choosed: 0,
                bsb_choosed: 0,
              },
              {
                onSuccess: (res) => {
                  setPromoData(res.data.data);
                },
              }
            );
            queryClient.invalidateQueries({ queryKey: ["cart"] });
          },
        });
      });

      setItems(localItems);
    }
    setHasPendingChanges(false);
    onQuantityChange(false);
  };

  const handleCheckboxChange = (id: string) => {
    setSelectedItems((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const selectedCount = useMemo(() => selectedItems.size, [selectedItems]);

  const columns = useMemo(() => {
    const columnsList: ColumnDef<ProductDetail>[] = [
      {
        header: "Product Name",
        accessorKey: "title",
        cell: ({ row }) => {
          const isOutOfStock = row.original.stock_qty === 0;
          return (
            <HStack alignItems="stretch">
              <Flex alignItems="center" justifyContent="center" boxSize="80px">
                <Box position={"relative"} overflow={"hidden"}>
                  <Image
                    src={
                      row.original.image || config?.company_details_url || ""
                    }
                    alt={row.original.title}
                    width={80}
                    height={80}
                    style={{
                      opacity: isOutOfStock ? 0.5 : 1,
                    }}
                  />
                  {/* Discount Ribbon */}
                  {row.original.discount_percentage &&
                  Number(row.original.discount_percentage) > 0 ? (
                    <Box
                      position="absolute"
                      top=" -25px"
                      right="-34px"
                      width="113px"
                      height="45px"
                      bg="green.500"
                      color="white"
                      textAlign="center"
                      lineHeight="1"
                      fontSize="sm"
                      fontWeight="bold"
                      transform="rotate(45deg)"
                      py={1}
                      zIndex="1"
                    >
                      <HStack
                        gap="0"
                        align="flex-start"
                        position={"absolute"}
                        top=" 24px"
                        dropShadow={"md"}
                        right="22px"
                        rotate={"-45deg"}
                      >
                        <Box
                          textShadow="9px 1px 3px #22c55e"
                          fontSize="16px"
                          letterSpacing={"-1px"}
                        >
                          -{row.original.discount_percentage}%
                        </Box>
                      </HStack>
                    </Box>
                  ) : null}
                </Box>
              </Flex>
              <Stack
                justifyContent="center"
                onClick={() =>
                  !isOutOfStock &&
                  router.push(`${ROUTES.APP.PRODUCTS}/${row.original.title}`)
                }
                cursor={isOutOfStock ? "not-allowed" : "pointer"}
              >
                <Heading
                  variant="heading7"
                  color={isOutOfStock ? "gray.400" : "primary.400"}
                >
                  {row.original.name?.length > 18
                    ? `${row.original.name?.slice(0, 18)}...`
                    : row.original.name}
                  {isOutOfStock && (
                    <Text as="span" color="red.500" ml={2}>
                      (Out of Stock)
                    </Text>
                  )}
                </Heading>
                <Text variant="subtitle3" color="primary.300">
                  {row.original.type}
                  {row.original.subType && ` / ${row.original.subType}`}
                </Text>
              </Stack>
            </HStack>
          );
        },
      },
      {
        header: "Quantity",
        accessorKey: "quantity",
        meta: { textAlign: "center" },
        cell: ({ row }) => {
          const item = row.original;
          const isOutOfStock = item.stock_qty === 0;
          const minimumQuantity = Math.max(item.minimumQuantity || 1, 1);
          const maximumQuantity = item.stock_qty;
          const incrementStep = item.incrementStep || 1;
          const isMaxReached = item.quantity >= maximumQuantity;
          const isMinReached = item.quantity <= minimumQuantity;
          // Calculate the effective minimum (can't be more than maximum)
          const effectiveMin = Math.min(minimumQuantity, maximumQuantity);

          return (
            <Box>
              <QuantityInput
                value={item.quantity}
                onChange={(value) => {
                  // Ensure value is between effectiveMin and maximumQuantity
                  const newValue = Math.max(
                    effectiveMin,
                    Math.min(value, maximumQuantity)
                  );
                  handleQuantityChange(item.id, newValue);
                }}
                quantityPayload={(quantityChange) => {
                  const newQuantity = item.quantity + quantityChange;
                  // Ensure new quantity stays within bounds
                  if (newQuantity < effectiveMin) return;
                  if (newQuantity > maximumQuantity) return;
                  handleQuantityChange(item.id, newQuantity);
                }}
                minimum={effectiveMin}
                maximum={maximumQuantity}
                incrementStep={incrementStep}
                disabled={isOutOfStock}
                showMaxReached={isMaxReached}
                showMinReached={isMinReached}
              />
            </Box>
          );
        },
      },
      {
        header: "Rate",
        accessorKey: "price",
        cell: ({ row }) => (
          <VStack gap="0">
            <Text color={row.original.stock_qty === 0 ? "gray.400" : "inherit"}>
              {config?.currency} {row.original.discountedPrice}
            </Text>
            {row.original.discountedPrice !== row.original.price ? (
              <Text color="red.400" textDecoration={"line-through"}>
                {config?.currency} {row.original.price}
              </Text>
            ) : null}
          </VStack>
        ),
      },
      {
        header: "Total",
        accessorFn: (row: ProductDetail) => {
          return parseInt(row.price) * row.quantity;
        },
        cell: ({ row }) => {
          const total =
            parseFloat(row.original.discountedPrice) * row.original.quantity;
          const formattedTotal =
            total % 1 === 0
              ? total
              : total
                  .toFixed(2)
                  .replace(/\.00$/, "")
                  .replace(/(\.\d)0$/, "$1");

          return (
            <HStack gap="0">
              <Text
                color={row.original.stock_qty === 0 ? "gray.400" : "inherit"}
              >
                {config?.currency} {formattedTotal}
              </Text>
            </HStack>
          );
        },
      },
    ];
    return columnsList;
  }, [config?.currency, router]);

  return (
    <Box flex={1}>
      <Stack gap="2px">
        <HStack alignItems="stretch" justifyContent="space-between">
          <Stack gap="8px">
            <Heading
              display={{ base: "none", md: "block" }}
              variant={{
                base: "heading5",
                "2xl": "heading4",
              }}
            >
              Cart Summary ({originalItems.length} Items)
            </Heading>

            <Text
              display={{ base: "block", md: "none" }}
              fontSize={"16px"}
              fontWeight={500}
            >
              Cart Summary ({originalItems.length} Items)
            </Text>

            <Text variant="paragraphSmall" color="system.text.light.light">
              Review your items and proceed to checkout
            </Text>
          </Stack>

          <HStack>
            <CartDeleteButton
              onClick={handleRemoveFromCart}
              count={selectedCount}
              isLoading={isRemovingFromCart}
            />
            {hasPendingChanges && (
              <Button
                borderRadius="8px"
                bg={"primary.500"}
                color={"gray.700"}
                onClick={handleApplyChanges}
                size="sm"
              >
                Apply Changes
              </Button>
            )}
          </HStack>
        </HStack>

        <Box display={{ base: "none", md: "block" }}>
          <TableWithCheckbox
            columns={columns}
            data={localItems}
            selectedItems={selectedItems}
            setSelectedItems={setSelectedItems}
            onSelectionChange={handleCheckboxChange}
          />
        </Box>
        {/* ==================Mobile view ================== */}
        <Box display={{ base: "block", md: "none" }} mb={2}>
          <Stack gap={4}>
            {localItems.map((item) => {
              const isOutOfStock = item.stock_qty === 0;
              const minimumQuantity = Math.max(item.minimumQuantity || 1, 1);
              const maximumQuantity = item.stock_qty;
              const incrementStep = item.incrementStep || 1;
              const isMaxReached = item.quantity >= maximumQuantity;
              const isMinReached = item.quantity <= minimumQuantity;
              const effectiveMin = Math.min(minimumQuantity, maximumQuantity);

              return (
                <Box
                  key={item.id}
                  borderWidth="1px"
                  borderRadius="md"
                  position={"relative"}
                  overflow={"hidden"}
                  padding={4}
                >
                  {/* Discount Ribbon */}
                  {item.discount_percentage &&
                  Number(item.discount_percentage) > 0 ? (
                    <Box
                      position="absolute"
                      top=" -17px"
                      right="-68px"
                      width="162px"
                      height="74px"
                      bg="green.500"
                      color="white"
                      textAlign="center"
                      lineHeight="1"
                      fontSize="sm"
                      fontWeight="bold"
                      transform="rotate(45deg)"
                      py={1}
                      zIndex="1"
                    >
                      <HStack
                        gap="0.6rem"
                        align="center"
                        position={"absolute"}
                        top=" 2.4rem"
                        dropShadow={"md"}
                        right="3.4rem"
                        rotate={"-45deg"}
                      >
                        <Box
                          textShadow="9px 1px 3px #22c55e"
                          css={{
                            WebkitTextStrokeWidth: "3px",
                            WebkitTextStrokeColor: "#22c55e",
                          }}
                          letterSpacing="-6px"
                          fontSize="3.5rem"
                        >
                          {item.discount_percentage}
                        </Box>
                        <VStack gap="0">
                          <Text>%</Text>
                          <Text>OFF</Text>
                        </VStack>
                      </HStack>
                    </Box>
                  ) : null}
                  {/* updating the checkbox */}
                  <Checkbox
                    height={"16px"}
                    width={"16px"}
                    checked={selectedItems.has(item.id)}
                    onChange={() => handleCheckboxChange(item.id)}
                    disabled={isOutOfStock}
                  />
                  <HStack align="center" gap={4}>
                    <Box position={"relative"}>
                      <Image
                        src={item.image || config?.company_details_url || ""}
                        alt={item.title}
                        width={90}
                        height={90}
                        objectFit="cover"
                      />
                    </Box>
                    <Stack gap={1} flex="1">
                      <Text
                        fontWeight="bold"
                        fontSize="md"
                        w={
                          item.discount_percentage &&
                          Number(item.discount_percentage) > 0
                            ? "80%"
                            : "auto"
                        }
                        onClick={() =>
                          !isOutOfStock &&
                          router.push(`${ROUTES.APP.PRODUCTS}/${item.title}`)
                        }
                        cursor={isOutOfStock ? "not-allowed" : "pointer"}
                      >
                        {item.name?.length > 40
                          ? `${item.name.slice(0, 40)}...`
                          : item.name}
                        {isOutOfStock && (
                          <Text as="span" color="red.500" ml={1}>
                            (Out of Stock)
                          </Text>
                        )}
                      </Text>
                      <Text fontSize="sm" color="gray.500">
                        {item.type}
                        {item.subType && ` / ${item.subType}`}
                      </Text>
                      <QuantityInput
                        value={item.quantity}
                        onChange={(value) => {
                          const newValue = Math.max(
                            effectiveMin,
                            Math.min(value, maximumQuantity)
                          );
                          handleQuantityChange(item.id, newValue);
                        }}
                        quantityPayload={(quantityChange) => {
                          const newQuantity = item.quantity + quantityChange;
                          if (newQuantity < effectiveMin) return;
                          if (newQuantity > maximumQuantity) return;
                          handleQuantityChange(item.id, newQuantity);
                        }}
                        minimum={effectiveMin}
                        maximum={maximumQuantity}
                        incrementStep={incrementStep}
                        disabled={isOutOfStock}
                        showMaxReached={isMaxReached}
                        showMinReached={isMinReached}
                      />
                    </Stack>
                  </HStack>
                  <Flex
                    justifyContent="space-between"
                    alignItems="center"
                    mt={3}
                  >
                    <VStack gap="0">
                      <Text
                        color={item.stock_qty === 0 ? "gray.400" : "inherit"}
                      >
                        {config?.currency} {item.discountedPrice}
                      </Text>
                      {item.discountedPrice !== item.price ? (
                        <Text color="red.400" textDecoration={"line-through"}>
                          {config?.currency} {item.price}
                        </Text>
                      ) : null}
                    </VStack>
                    <Text color={isOutOfStock ? "gray.400" : "inherit"}>
                      Total: {config?.currency}{" "}
                      {(parseFloat(item.discountedPrice) * item.quantity) %
                        1 ===
                      0
                        ? parseFloat(item.discountedPrice) * item.quantity
                        : (parseFloat(item.discountedPrice) * item.quantity)
                            .toFixed(2)
                            .replace(/\.00$/, "")
                            .replace(/(\.\d)0$/, "$1")}
                    </Text>
                  </Flex>
                </Box>
              );
            })}
          </Stack>
        </Box>
      </Stack>
    </Box>
  );
};
