"use client";

import { savePayment } from "@/api/queries/savePayment";
import {
  Box,
  Center,
  Flex,
  Heading,
  Icon,
  Link,
  Text,
  VStack,
  Button,
  Spinner,
} from "@chakra-ui/react";
import { CheckCircle } from "lucide-react";
import NextLink from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";

export default function PaymentSuccess() {
  const searchParams = useSearchParams();
  const [status, setStatus] = useState<"loading" | "success" | "error">(
    "loading"
  );
  const [orderId, setOrderId] = useState<string | null>(null);

  const isLoading = status === "loading";
  const isSuccess = status === "success";
  const isError = status === "error";

  useEffect(() => {
    const id = searchParams.get("order_id");
    if (id) {
      setOrderId(id);
    }
  }, [searchParams]);

  useEffect(() => {
    const save = async () => {
      if (!orderId) return;

      try {
        await savePayment(orderId);
        setStatus("success");
      } catch {
        setStatus("error");
      }
    };

    save();
  }, [orderId]);

  return (
    <Flex
      minH="100dvh"
      justify="center"
      align="center"
      bgGradient={"linear(to-r, gray.900, gray.800)"}
      px={4}
    >
      <Box
        w="full"
        maxW="2xl"
        p={{ base: 4, sm: 10 }}
        shadow="2xl"
        rounded="3xl"
      >
        <Center>
          <Flex
            w={20}
            h={20}
            bg={isSuccess ? "green.700" : isError ? "red.500" : "yellow.500"}
            rounded="full"
            align="center"
            justify="center"
            mb={6}
          >
            {isLoading ? (
              <Spinner size="xl" color="white" />
            ) : (
              <Icon
                as={CheckCircle}
                boxSize={12}
                color={isSuccess ? "green.600" : "red.600"}
              />
            )}
          </Flex>
        </Center>

        <VStack gap={4} textAlign="center">
          <Heading
            fontSize="4xl"
            fontWeight="extrabold"
            color={
              isSuccess ? "green.700" : isLoading ? "yellow.500" : "red.700"
            }
          >
            {isLoading
              ? "Please don’t exit this page"
              : isSuccess
                ? "Payment Successful!"
                : "Payment Failed"}
          </Heading>

          <Text fontSize="lg" color={"gray.800"}>
            {isLoading
              ? "Your payment is being processed..."
              : isSuccess
                ? "Thank you for your purchase."
                : "We couldn’t process your payment. Please contact support."}
          </Text>

          <Text fontSize="sm" color={"gray.700"}>
            If you have any questions or need assistance, contact us at:{" "}
            <Link
              href="mailto:info@hamaglobal.com.au"
              color={"indigo.600"}
              fontWeight="medium"
              textDecoration="underline"
            >
              info@hamaglobal.com.au
            </Link>
          </Text>
        </VStack>

        <Center mt={8}>
          <NextLink href="/profile" passHref legacyBehavior>
            <Button
              as="a"
              display={isLoading ? "none" : ""}
              px={6}
              py={2}
              fontSize="lg"
              fontWeight="medium"
              color="white"
              bgGradient="linear(to-r, indigo.600, blue.600)"
              _hover={{
                transform: "scale(1.05)",
                bgGradient: "linear(to-r, indigo.700, blue.700)",
              }}
              rounded="full"
              shadow="lg"
            >
              Back to Profile
            </Button>
          </NextLink>
        </Center>
      </Box>
    </Flex>
  );
}
