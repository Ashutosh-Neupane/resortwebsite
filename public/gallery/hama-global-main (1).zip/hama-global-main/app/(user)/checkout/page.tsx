"use client";
import { getStripeData } from "@/api/queries/stripe";
import { DNDTS } from "@/assets/image";
import { Visa } from "@/assets/svg";
import { toaster } from "@/components";
import { useCheckoutStore } from "@/store/products/checkoutStore";
import {
  Box,
  Flex,
  Text,
  Heading,
  Stack,
  VStack,
  Badge,
  Icon,
  Image,
} from "@chakra-ui/react";
import { CheckCircle, ShieldCheck } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";

const OrderSummary = () => {
  const [selectedPayment, setSelectedPayment] = useState("Card");
  const router = useRouter();
  // const { promoData: calculationData } = usePromoStore();
  // const subTotal = calculationData?.total ?? 0;
  // const EstimatedTax = calculationData?.total_tax ?? 0;

  const checkoutData = useCheckoutStore((state) => state.checkoutData);

  if (!checkoutData) {
    return <p>Loading checkout data...</p>;
  }

  // Payment method options
  const paymentMethods = [
    {
      id: "Card",
      name: "Visa / Mastercard",
      description: "Visa, Mastercard, Amex",
      icon: Visa,
    },
    // {
    //   id: "Esewa",
    //   name: "Esewa",
    //   description: "Fast and secure",
    //   icon: Esewa,
    // },
    // {
    //   id: "Khalti",
    //   name: "Khalti",
    //   description: "Fast and secure",
    //   icon: Khalti,
    // },
    // {
    //   id: "Fonepay",
    //   name: "Fonepay",
    //   description: "Direct deposit",
    //   icon: Fonepay,
    // },
  ];

  // Handle Payment Method Selection
  const handlePayment = async () => {
    if (selectedPayment === "Card") {
      try {
        // Get Stripe data (redirect URL)
        const stripeData = await getStripeData();

        // Redirect to the Card payment page
        if (stripeData?.message.url) {
          router.push(stripeData.message.url);
        } else {
          // alert("Error fetching Card data");
          toaster.create({
            title: "Error fetching Card data",
            type: "error",
          });
        }
      } catch (error) {
        toaster.create({
          title: error || "Error fetching Card data",
          type: "error",
        });
      }
    } else if (["Khalti", "Esewa", "Fonepay"].includes(selectedPayment)) {
      toaster.create({
        title: "Payment method currently unavailable",
        type: "error",
      });
    }
  };

  return (
    <>
      <Box
        bgGradient="linear(to-br, gray.900, purple.900)"
        minH="100dvh"
        py={{ base: 6, md: 12 }}
        px={4}
        color="white"
        position="relative"
        overflow="hidden"
      >
        <Box maxW="6xl" mx="auto" position="relative" zIndex="1">
          {/* Header */}
          <Box direction="column" textAlign="center" mb={{ base: 6, md: 10 }}>
            <Heading
              size="xl"
              textAlign="start"
              bgGradient="linear(to-r, purple.400, pink.400)"
              bgClip="text"
              color={"gray.400"}
              fontWeight="extrabold"
              letterSpacing="tight"
              mb={3}
            >
              Complete Your Payment
            </Heading>
          </Box>

          {/* Main content - Flex layout for desktop */}
          <Flex
            direction={{ base: "column", lg: "row" }}
            gap={{ base: 6, lg: 8 }}
            align="stretch"
          >
            {/* Order Summary - Left side on desktop */}
            <Box
              flex={{ lg: "1" }}
              bg="rgba(26, 32, 44, 0.7)"
              backdropFilter="blur(10px)"
              p={{ base: 6, md: 8 }}
              borderRadius="2xl"
              boxShadow="0 10px 30px -5px rgba(0, 0, 0, 0.3)"
              border="1px solid"
              borderColor="gray.700"
              transition="all 0.3s"
            >
              <Flex justify="space-between" align="center">
                <Heading size="md" color="purple.400" fontWeight="bold">
                  Order Summary
                </Heading>
                <Badge
                  colorScheme="purple"
                  fontSize="sm"
                  px={3}
                  py={1}
                  borderRadius="full"
                  textTransform="none"
                >
                  Pending
                </Badge>
              </Flex>

              {/* Custom divider */}
              <Box
                h="20px"
                w="100%"
                bgGradient="linear(to-r, transparent, purple.500, transparent)"
                mb={6}
              />

              <VStack gap={4} align="stretch">
                <Flex justify="space-between">
                  <Text fontWeight="medium" color="gray.400">
                    Customer:
                  </Text>
                  <Text fontWeight="medium">{checkoutData?.customer}</Text>
                </Flex>

                <Flex justify="space-between">
                  <Text fontWeight="medium" color="gray.400">
                    Order ID:
                  </Text>
                  <Text fontFamily="mono" fontWeight="medium">
                    {checkoutData?.order_id}
                  </Text>
                </Flex>
                <Flex justify="space-between">
                  <Text fontWeight="medium" color="gray.400">
                    Description:
                  </Text>
                  <Text fontFamily="mono" fontWeight="medium">
                    {checkoutData?.description}
                  </Text>
                </Flex>

                <Box
                  p={4}
                  bg="gray.800"
                  borderRadius="lg"
                  border="1px solid"
                  borderColor="gray.700"
                  mt={2}
                >
                  {/* <Text fontWeight="medium" color="gray.400" mb={3}>
                  Order Details:
                </Text> */}
                  {/* <Flex justify="space-between" mb={2}>
                  <Text fontSize="sm">Sub-total </Text>
                  <Text fontSize="sm" fontWeight="medium">
                    {subTotal}
                  </Text>
                </Flex>
                <Flex justify="space-between" mb={2}>
                  <Text fontSize="sm">Tax</Text>
                  <Text fontSize="sm">{EstimatedTax}</Text>
                </Flex> */}
                  {/* <Box h="1px" w="100%" bg="gray.700" my={2} /> */}
                  <Flex justify="space-between" mt={2}>
                    <Text fontWeight="bold">Total Amount</Text>
                    <Text fontSize="xl" fontWeight="bold" color="pink.400">
                      {checkoutData?.amount}
                    </Text>
                  </Flex>
                </Box>

                <Flex
                  mt={4}
                  p={3}
                  bg="gray.800"
                  borderRadius="lg"
                  align="center"
                  border="1px solid"
                  borderColor="gray.700"
                >
                  <Icon as={ShieldCheck} color="green.400" mr={3} />
                  <Text fontSize="sm" color="gray.300">
                    Your payment is protected with secure encryption
                  </Text>
                </Flex>
              </VStack>
            </Box>

            {/* Payment Methods  */}
            <Box
              flex={{ lg: "1.2" }}
              bg="rgba(26, 32, 44, 0.7)"
              backdropFilter="blur(10px)"
              p={{ base: 6, md: 8 }}
              borderRadius="2xl"
              alignItems={"center"}
              boxShadow="0 10px 30px -5px rgba(0, 0, 0, 0.3)"
              border="1px solid"
              alignContent={"center"}
              borderColor="gray.700"
            >
              <Heading size="md" mb={6} color="purple.400" fontWeight="bold">
                Payment Method
              </Heading>

              <Stack gap={4}>
                {paymentMethods.map((method) => (
                  <Box
                    key={method.id}
                    p={2}
                    borderRadius="xl"
                    border="1px solid"
                    borderColor={
                      selectedPayment === method.id ? "purple.500" : "gray.700"
                    }
                    borderWidth={selectedPayment === method.id ? "2px" : "1px"}
                    // bg={
                    //   selectedPayment === method.id
                    //     ? "rgba(124, 58, 237, 0.1)"
                    //     : "transparent"
                    // }
                    cursor="pointer"
                    onClick={() => setSelectedPayment(method.id)}
                    transition="all 0.2s"
                    position="relative"
                    overflow="hidden"
                  >
                    {selectedPayment === method.id && (
                      <Box position="absolute" top={2} right={2}>
                        <Icon as={CheckCircle} color="green.400" />
                      </Box>
                    )}
                    <Flex align="center">
                      <Flex
                        justify="center"
                        align="center"
                        // bg={
                        //   selectedPayment === method.id
                        //     ? "purple.500"
                        //     : "gray.800"
                        // }
                        w={12}
                        h={12}
                        borderRadius="lg"
                        mr={4}
                        transition="all 0.2s"
                      >
                        <Icon as={method.icon} color="white" w={12} h={12} />
                      </Flex>
                      <Box>
                        <Text fontWeight="medium">{method.name}</Text>
                        <Text fontSize="xs" color="gray.400">
                          {method.description}
                        </Text>
                      </Box>
                    </Flex>
                  </Box>
                ))}
              </Stack>

              {/* Pay Button */}
              <Box mt={8}>
                <Box
                  as="button"
                  w="full"
                  bg="gray.800"
                  color="white"
                  py={4}
                  borderRadius="xl"
                  fontWeight="bold"
                  fontSize="lg"
                  onClick={handlePayment}
                  _hover={{
                    transform: "translateY(-2px)",
                    boxShadow: "0 10px 20px -10px rgba(159, 122, 234, 0.7)",
                  }}
                  _active={{
                    transform: "translateY(0)",
                    boxShadow: "none",
                  }}
                  transition="all 0.3s"
                >
                  Pay {checkoutData?.amount} AUD
                </Box>
              </Box>
            </Box>
          </Flex>
        </Box>
      </Box>
      <Box as="footer" maxW={"7xl"} mx={"auto"} py={8}>
        <Flex
          justify="space-between"
          align="left"
          maxW={"6xl"}
          mx={"auto"}
          py={6}
          flexWrap={{ base: "wrap", md: "nowrap" }}
          gap={4}
        >
          <Flex direction="column" gap={2}>
            <Image
              src={DNDTS.src}
              alt="Dots and Dashes Logo"
              width={"120px"}
              height={"60px"}
              objectFit="contain"
            />
            <Text fontSize="sm" color="gray.600">
              &copy; Dots and Dashes Technology Services Pvt. Ltd.
            </Text>
            <Text fontSize="sm" color="gray.600">
              Golfutar, Kathmandu, Nepal
            </Text>
          </Flex>

          <Text fontSize="sm" color="gray.500" alignSelf={"center"}>
            Powered By Dots and Dashes Technology Services Pvt. Ltd.
          </Text>
        </Flex>
      </Box>
    </>
  );
};

export default OrderSummary;
