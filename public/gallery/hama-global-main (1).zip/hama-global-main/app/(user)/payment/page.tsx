"use client";

import { useEffect, useState } from "react";
import { Flex } from "@chakra-ui/react";

import { PageTitle } from "@/components";
import { BREADCRUMB_CONFIG } from "@/config";
import { ROUTES } from "@/constants";

import { DeliveryNote, PaymentMethod, Summary } from "./(components)";
import { useAddPromo } from "@/hooks/api";
import { usePromoFormStore, usePromoStore } from "@/store";

const Payment = () => {
  const { promoData } = usePromoStore();
  const [selectedPaymentMethod, setSelectedPaymentMethod] =
    useState<string>("");
  const [deliveryAddress, setDeliveryAddress] = useState<string>("");
  const [billingAddress, setBillingAddress] = useState<string>("");
  const [deliveryNote, setDeliveryNote] = useState<string>("");
  const [referenceCode, setReferenceCode] = useState<string>("");
  const [surgeCharge, setSurgeCharge] = useState<number>(
    promoData?.surge_charges || 0
  );

  const { mutate: applyPromo } = useAddPromo();
  const { setPromoData } = usePromoStore();
  const { promoCode, deliveryLocation } = usePromoFormStore();

  // const handlePaymentMethodChange = (details: { value: string }) => {
  //   setSelectedPaymentMethod(details.value);
  // };
  const handlePaymentMethodChange = (details: { value: string | null }) => {
    if (details.value) {
      setSelectedPaymentMethod(details.value);
    }
  };

  useEffect(() => {
    if (selectedPaymentMethod === "Visa / Mastercard") {
      applyPromo(
        {
          coupon: promoCode?.trim() || "",
          delivery_charge: deliveryLocation,
          online_payment_choosed: 1,
          bsb_choosed: 0,
        },
        {
          onSuccess: (response) => {
            setPromoData(response.data.data);
          },
        }
      );
    } else if (selectedPaymentMethod === "BSB Payment") {
      applyPromo(
        {
          coupon: promoCode?.trim() || "",
          delivery_charge: deliveryLocation,
          online_payment_choosed: 0,
          bsb_choosed: 1,
        },
        {
          onSuccess: (response) => {
            setPromoData(response.data.data);
          },
        }
      );
    } else {
      applyPromo(
        {
          coupon: promoCode?.trim() || "",
          delivery_charge: deliveryLocation,
          online_payment_choosed: 0,
          bsb_choosed: 0,
        },
        {
          onSuccess: (response) => {
            setPromoData(response.data.data);
          },
        }
      );
    }
  }, [selectedPaymentMethod]);

  return (
    <>
      <PageTitle
        backLabel="Back to Cart Summary"
        backLink={ROUTES.USER.CART}
        title="Checkout"
        breadcrumb={BREADCRUMB_CONFIG.PAYMENT}
      />

      <Flex
        flexDirection={{ base: "column", md: "column", lg: "row" }}
        maxWidth={"1280px"}
        mx={"auto"}
        gap={{ md: "20px", lg: "40px", xl: "60px" }}
        alignItems={"stretch"}
        py={8}
        px={{ base: "20px", lg: "40px" }}
      >
        <PaymentMethod
          selectedPaymentMethod={selectedPaymentMethod}
          handlePaymentMethodChange={handlePaymentMethodChange}
          setDeliveryAddress={setDeliveryAddress}
          setBillingAddress={setBillingAddress}
          setDeliveryNote={setDeliveryNote}
          setReferenceCode={setReferenceCode}
          setSurgeCharge={setSurgeCharge}
        />
        <Summary
          selectedPaymentMethod={selectedPaymentMethod}
          delivery_Address={deliveryAddress}
          billing_Address={billingAddress}
          delivery_note={deliveryNote}
          referenceCode={referenceCode}
          surge_charges={surgeCharge}
        />
      </Flex>

      {/* New Full-Width Delivery Note Section */}
      <DeliveryNote
        deliveryNote={deliveryNote}
        setDeliveryNote={setDeliveryNote}
      />
    </>
  );
};

export default Payment;
