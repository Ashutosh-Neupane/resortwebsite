import { Box, Flex, Stack, Text, Button, Input } from "@chakra-ui/react";
import { useState } from "react";
import { Dialog } from "@/components/ui/dialog";
import { Radio, RadioGroup } from "@/components";
import { useAddAddress } from "@/hooks/api";

type AddressEntry = {
  address_type: string;
  address: string;
};

type Props = {
  addressInfo?: AddressEntry[];
  open: boolean;
  onClose: () => void;
};

export const DeliveryAddressSelector = ({ open, onClose }: Props) => {
  const [newAddress, setNewAddress] = useState("");
  const [newAddressType, setNewAddressType] = useState("Shipping");
  const { mutate: addAddress } = useAddAddress();

  const handleAddAddress = () => {
    const payload = {
      address_type: newAddressType,
      address: newAddress,
    };

    addAddress(payload, {
      onSuccess: () => {
        setNewAddress("");
        setNewAddressType("Shipping");
        onClose();
      },
    });
  };
  return (
    <Dialog
      open={open}
      onClose={onClose}
      title="Add New Address"
      size={{ base: "xs", sm: "sm", md: "md", lg: "xl" }}
      hasCloseTrigger
      contentMinWidth={{ base: "100%", md: "400px" }}
    >
      <Box p={{ base: 4, md: 6 }}>
        {/* Address Type */}
        <Box mb={6}>
          <Text fontSize="md" fontWeight="medium" mb={2}>
            Address Type
          </Text>
          <RadioGroup
            value={newAddressType}
            onValueChange={(details) => {
              if (details.value) {
                setNewAddressType(details.value);
              }
            }}
          >
            <Stack direction={{ base: "column", sm: "row" }} gap={4}>
              <Radio fontSize="md" value="Shipping" colorScheme="green">
                Shipping
              </Radio>
              <Radio fontSize="md" value="Billing" colorScheme="green">
                Billing
              </Radio>
            </Stack>
          </RadioGroup>
        </Box>

        {/* Address Field */}
        <Box mb={6}>
          <Text fontSize="md" fontWeight="medium" mb={2}>
            Address
          </Text>
          <Input
            value={newAddress}
            onChange={(e) => setNewAddress(e.target.value)}
            placeholder="Enter address"
          />
        </Box>

        {/* Action Buttons */}
        <Flex justify="flex-end" gap={3}>
          <Button bg={"green.500"} variant="primary" onClick={onClose}>
            Cancel
          </Button>
          <Button
            colorScheme="green"
            onClick={handleAddAddress}
            disabled={!newAddress.trim()}
          >
            Add
          </Button>
        </Flex>
      </Box>
    </Dialog>
  );
};
