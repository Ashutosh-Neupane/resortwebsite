"use client";
import {
  Box,
  Flex,
  Heading,
  Image,
  Spinner,
  Stack,
  Text,
  VStack,
} from "@chakra-ui/react";
import { FormProvider, useForm } from "react-hook-form";
import { useState, useEffect } from "react";

import { Radio, RadioGroup } from "@/components";
import { usePaymentMethods } from "@/hooks/app";
import { PaymentMethodProps } from "@/types";
import { useUserProfileQuery } from "@/hooks/api";
import { AddIcon } from "@/assets/svg";
import { DeliveryAddressSelector } from "./DeliveryAddressSection ";

export const PaymentMethod = ({
  selectedPaymentMethod,
  handlePaymentMethodChange,
  setDeliveryAddress,
  setBillingAddress,
  setReferenceCode,
}: PaymentMethodProps) => {
  const { items, isLoading } = usePaymentMethods();
  const { data: profileData } = useUserProfileQuery();

  const methods = useForm();
  const {
    watch,
    register,
    setValue,
    formState: { errors },
  } = methods;

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isBillingSameAsShipping, setIsBillingSameAsShipping] = useState(false);

  const referenceCode = watch("referenceCode");
  useEffect(() => {
    if (selectedPaymentMethod === "BSB Payment" && referenceCode) {
      setReferenceCode(referenceCode);
    } else {
      setReferenceCode("");
    }
  }, [referenceCode, selectedPaymentMethod, setReferenceCode]);

  const handleBillingSameAsShippingChange = (value: boolean) => {
    setIsBillingSameAsShipping(value);
    const selectedShippingAddress = watch("selectedShippingAddressType");

    if (value) {
      setBillingAddress(selectedShippingAddress);
      setValue("selectedBillingAddressType", selectedShippingAddress);
    } else {
      setBillingAddress("");
      setValue("selectedBillingAddressType", "");
    }
  };

  useEffect(() => {
    if (selectedPaymentMethod !== "BSB Payment") {
      setValue("referenceCode", "");
    }
  }, [selectedPaymentMethod, setValue]);

  return (
    <Box flex={1}>
      <Stack gap={2}>
        <Heading
          fontWeight={400}
          fontSize={{ base: "20px", lg: "24px", xl: "28px" }}
        >
          Payment Details
        </Heading>
        <Text variant="paragraphSmall" color="primary.300" mb="16px">
          Please select payment method to confirm order.
        </Text>
      </Stack>

      {isLoading ? (
        <Box mt={12} display="flex" alignItems="center">
          <Spinner size="md" />
        </Box>
      ) : (
        <Box
          border="1px solid"
          borderColor="primary.100"
          borderRadius="24px"
          p="24px"
        >
          <Text mb={4} variant="subtitle1">
            Payment Method
          </Text>

          <RadioGroup
            value={selectedPaymentMethod}
            onValueChange={handlePaymentMethodChange}
          >
            <Flex
              direction={{ base: "column", md: "row" }}
              gap={{ base: "24px", md: "20px", lg: "32px" }}
              wrap="wrap"
            >
              {items.map(({ value, description, icon }) => (
                <Radio
                  key={value}
                  value={value}
                  w={{ base: "100%", md: "auto" }}
                  border="1px solid"
                  borderColor="primary.100"
                  borderRadius="16px"
                  px="16px"
                  py="16px"
                >
                  <Flex align="center" gap={4}>
                    <Image
                      h="60px"
                      w="60px"
                      objectFit="contain"
                      src={icon}
                      alt={value}
                    />
                    <Stack gap={1}>
                      <Text variant={{ base: "subtitle2", lg: "subtitle1" }}>
                        {value}
                      </Text>
                      <Text
                        variant={{ base: "subtitle3", lg: "paragraphSmall" }}
                        color="primary.300"
                      >
                        {description}
                      </Text>
                    </Stack>
                  </Flex>
                </Radio>
              ))}
            </Flex>
          </RadioGroup>

          {/* Show Reference Code and Bank Details only for BSB Payment */}
          {selectedPaymentMethod === "BSB Payment" && (
            <Box mt={6}>
              {/* Reference Code Input */}
              <Box mb={4}>
                <Text fontWeight="semibold" mb={2}>
                  Reference Code <span style={{ color: "red" }}>*</span>
                </Text>
                <input
                  {...register("referenceCode", {
                    required: "Reference code is required for BSB Payment",
                  })}
                  placeholder="Enter your reference code"
                  style={{
                    width: "100%",
                    padding: "8px",
                    borderRadius: "8px",
                    border: "1px solid #ccc",
                  }}
                />
                {errors.referenceCode && (
                  <Text color="red.500" fontSize="sm" mt={1}>
                    {errors.referenceCode.message as string}
                  </Text>
                )}
              </Box>

              {/* Bank Details */}
              <Box>
                <Text fontWeight="semibold" mb={2}>
                  Bank Details
                </Text>
                <Box
                  border="1px solid"
                  borderColor="gray.300"
                  borderRadius="12px"
                  p={4}
                  bg="gray.50"
                >
                  <Flex justify="space-between" mb={2}>
                    <Text fontWeight="medium">Account Name</Text>
                    <Text>HAMA Global Pty Ltd</Text>
                  </Flex>
                  <Flex justify="space-between" mb={2}>
                    <Text fontWeight="medium">BSB</Text>
                    <Text>062-174 </Text>
                  </Flex>
                  <Flex justify="space-between">
                    <Text fontWeight="medium">Account Number</Text>
                    <Text>10777477</Text>
                  </Flex>
                </Box>
              </Box>
            </Box>
          )}
        </Box>
      )}

      <Box py={4}>
        <FormProvider {...methods}>
          <Box as="form">
            <VStack gap={6} align="stretch">
              <Box
                border="1px solid"
                borderColor="primary.100"
                borderRadius="24px"
                p="24px"
              >
                <Text
                  fontWeight="bold"
                  fontSize="lg"
                  mb={4}
                  pb={2}
                  borderBottom="2px solid"
                  borderColor="gray.600"
                  display="inline-block"
                >
                  Delivery Address
                </Text>

                {/* Shipping Address */}
                <Box mb={6}>
                  <Text fontWeight="semibold" mb={2}>
                    Shipping Address
                  </Text>
                  <select
                    {...register("selectedShippingAddressType")}
                    onChange={(e) => {
                      const selectedAddress = e.target.value;
                      setDeliveryAddress(selectedAddress);

                      if (isBillingSameAsShipping) {
                        setBillingAddress(selectedAddress);
                        setValue("selectedBillingAddressType", selectedAddress);
                      }
                    }}
                    style={{
                      width: "100%",
                      padding: "8px",
                      borderRadius: "8px",
                      border: "1px solid #ccc",
                      marginTop: "4px",
                      cursor: "pointer",
                    }}
                  >
                    <option value="">Select Shipping Address</option>
                    {profileData?.address_info
                      ?.filter(
                        (addr) =>
                          addr.address_type?.trim().toLowerCase() === "shipping"
                      )
                      .map((addr, idx) => (
                        <option key={`shipping-${idx}`} value={addr.address}>
                          {addr.address}
                        </option>
                      ))}
                  </select>
                </Box>

                {/* Billing Address */}
                <Box>
                  <Flex
                    direction={{ base: "column", sm: "row" }}
                    align={{ base: "flex-start", sm: "center" }}
                    mb={2}
                    gap={{ base: 1, sm: 4 }}
                  >
                    <Text fontWeight="semibold">Billing Address</Text>
                    <Flex align="center">
                      <input
                        type="checkbox"
                        id="sameAsShipping"
                        checked={isBillingSameAsShipping}
                        onChange={(e) =>
                          handleBillingSameAsShippingChange(e.target.checked)
                        }
                        style={{ marginRight: "8px" }}
                      />
                      <label htmlFor="sameAsShipping">
                        Same as shipping address
                      </label>
                    </Flex>
                  </Flex>

                  {!isBillingSameAsShipping && (
                    <select
                      {...register("selectedBillingAddressType")}
                      onChange={(e) => setBillingAddress(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "8px",
                        borderRadius: "8px",
                        border: "1px solid #ccc",
                        marginTop: "4px",
                        cursor: "pointer",
                      }}
                    >
                      <option value="">Select Billing Address</option>
                      {profileData?.address_info
                        ?.filter(
                          (addr) =>
                            addr.address_type?.trim().toLowerCase() ===
                            "billing"
                        )
                        .map((addr, idx) => (
                          <option key={`billing-${idx}`} value={addr.address}>
                            {addr.address}
                          </option>
                        ))}
                    </select>
                  )}
                </Box>

                {/* Add New Address */}
                <Box mt={6}>
                  <Flex alignItems="center">
                    <Text fontWeight="semibold" mr={3}>
                      Add New Address
                    </Text>
                    <Box
                      border="1px solid"
                      borderColor="primary.100"
                      borderRadius="8px"
                      p={2}
                      bg="primary.50"
                      cursor="pointer"
                      display="flex"
                      alignItems="center"
                      justifyContent="center"
                      onClick={() => setIsDialogOpen(true)}
                      _hover={{ bg: "primary.100" }}
                      role="button"
                      aria-label="Add new address"
                    >
                      <AddIcon color="primary.700" />
                    </Box>
                  </Flex>
                </Box>
              </Box>
            </VStack>
          </Box>

          <DeliveryAddressSelector
            onClose={() => setIsDialogOpen(false)}
            open={isDialogOpen}
            addressInfo={profileData?.address_info || []}
          />
        </FormProvider>
      </Box>
    </Box>
  );
};
