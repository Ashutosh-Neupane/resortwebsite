// components/DeliveryNote.tsx

"use client";

import { Box, Text } from "@chakra-ui/react";
import { FormProvider, useForm } from "react-hook-form";
import { useEffect, useState } from "react";

import { FormControl } from "@/components";

interface DeliveryNoteProps {
  deliveryNote: string;
  setDeliveryNote: (note: string) => void;
}

export const DeliveryNote = ({
  deliveryNote,
  setDeliveryNote,
}: DeliveryNoteProps) => {
  const methods = useForm({ defaultValues: { note: deliveryNote } });
  const { watch } = methods;

  const note = watch("note");
  const [debouncedNote, setDebouncedNote] = useState(note);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (note && note.trim() !== debouncedNote) {
        const trimmed = note.trim();
        setDebouncedNote(trimmed);
        setDeliveryNote(trimmed);
      }
    }, 1500);
    return () => clearTimeout(timer);
  }, [note, debouncedNote]);

  return (
    <Box maxWidth="1280px" mx="auto" px={{ base: 5, lg: 10 }} mb={6}>
      <Text fontSize={"lg"} fontWeight={"semibold"} mb={3}>
        Order Note
      </Text>
      <FormProvider {...methods}>
        <FormControl
          inputType="textarea"
          //   label="Delivery Note"
          placeholder="Add any specific delivery or order instructions"
          name="note"
        />
      </FormProvider>
    </Box>
  );
};
