import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

export interface CheckoutData {
  order_id: string;
  customer: string;
  currency: string;
  description: string;
  returnurl: string;
  cancelurl: string;
  amount: number;
}

interface CheckoutStore {
  checkoutData: CheckoutData | null;
  setCheckoutData: (data: CheckoutData) => void;
  clearCheckoutData: () => void;
}

export const useCheckoutStore = create<CheckoutStore>()(
  persist(
    (set) => ({
      checkoutData: null,
      setCheckoutData: (data) => set({ checkoutData: data }),
      clearCheckoutData: () => set({ checkoutData: null }),
    }),
    {
      name: "checkout-storage", 
      storage: createJSONStorage(() => sessionStorage), 
      partialize: (state) => ({ checkoutData: state.checkoutData }), 
    }
  )
);
