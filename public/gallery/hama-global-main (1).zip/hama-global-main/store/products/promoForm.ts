import { create } from "zustand";
import { persist } from "zustand/middleware";
import { PromoFormState } from "@/types";

export const usePromoFormStore = create<PromoFormState>()(
  persist(
    (set) => ({
      promoCode: "",
      deliveryLocation: "",
      surgeCharge: 0,
      resetFlag: false,
      setPromoCode: (code) => set({ promoCode: code }),
      setDeliveryLocation: (location) => set({ deliveryLocation: location }),
      setSurgeCharge: (surgeCharge) => set({ surgeCharge: surgeCharge }),
      resetPromoForm: () =>
        set({
          promoCode: "",
          deliveryLocation: "",
          resetFlag: true,
        }),
      clearResetFlag: () => set({ resetFlag: false }),
    }),
    {
      name: "promo-form-store",
    }
  )
);
