"use client";

import { useMemo, useState } from "react";

import { usePromoStore } from "@/store";

import { useConfigQuery, usePaymentMethodQuery } from "../api";

export const usePaymentMethods = () => {
  const { data: paymentMethod, isLoading, isError } = usePaymentMethodQuery();

  const items = useMemo(() => {
    if (!paymentMethod) return [];
    return paymentMethod.map((method) => ({
      icon: method.icon_link,
      description: method.description,
      value: method.name,
    }));
  }, [paymentMethod]);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("");

  const handlePaymentMethodChange = (value: string) => {
    setSelectedPaymentMethod(value);
  };

  return {
    items,
    selectedPaymentMethod,
    handlePaymentMethodChange,
    isLoading,
    isError,
    isEmpty: !isLoading && items.length === 0,
  };
};

export const useSummary = () => {
  const { data: config } = useConfigQuery();

  const { promoData: calculationData } = usePromoStore();

  const subTotal = calculationData?.total ?? 0;

  const ShippingValue = calculationData?.delivery_charge ?? 0;
  const EstimatedGST = calculationData?.total_tax ?? 0;
  const Discount = calculationData?.discount_amount ?? 0;
  const TotalAfterGST = calculationData?.total_after_tax ?? 0;
  const TotalAfterDiscount = calculationData?.grand_total_after_discount ?? 0;
  const SurgeCharge = calculationData?.surge_charges ?? 0;
  const summaryItems = [
    { label: "Sub Total", value: `${config.currency} ${subTotal}` },
    { label: "Discount", value: `${config.currency} ${Discount}` },
    {
      label: "Total After Discount",
      value: `${config.currency} ${TotalAfterDiscount}`,
    },
    { label: "GST", value: `${config.currency} ${EstimatedGST}` },
    { label: "Sub Total + GST", value: `${config.currency} ${TotalAfterGST}` },
    { label: "Shipping", value: `${config.currency} ${ShippingValue}` },
    { label: "Surge Charges", value: `${config.currency} ${SurgeCharge}` },
  ];

  const total = calculationData?.final_total;

  return { summaryItems, total };
};
