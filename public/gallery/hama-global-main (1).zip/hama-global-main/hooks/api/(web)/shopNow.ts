import { useQuery } from "@tanstack/react-query";

import { getShopNowPageData } from "@/api";
import { ShopNowAPIResponseType } from "@/types";

export const useShopNowPageQuery = (initialData?: ShopNowAPIResponseType) => {
  return useQuery({
    queryKey: ["shop-now"],
    queryFn: getShopNowPageData,
    initialData: initialData as ShopNowAPIResponseType,
    select: (data) => data.Data,
    staleTime: Infinity,
  });
};
