// "use client";

// import { orderPost } from "@/api";
// import { toaster } from "@/components";
// import { ROUTES } from "@/constants";
// import { ApiErrorResponse, OrderPostType } from "@/types";
// import { useMutation, useQueryClient } from "@tanstack/react-query";
// import { useRouter } from "next/navigation";

// export const useOrderMutation = (selectedPaymentMethod: string) => {
//   const router = useRouter();
//   const queryClient = useQueryClient();
//   return useMutation({
//     mutationFn: (data: OrderPostType) =>
//       orderPost({
//         items: data.items,
//         selectedPaymentMethod,
//       }),
//     onSuccess: (response) => {
//       toaster.create({
//         title: response?.data?.data?.message,
//         type: "success",
//       });

//       queryClient.invalidateQueries({ queryKey: ["cart-count"] });

//       if (selectedPaymentMethod === "Online Payment") {
//         // const paymentUrl = response?.data?.data?.payment_url;
//         // if (paymentUrl) {
//         //   window.location.href = paymentUrl;
//         // }
//       } else {
//         router.push(ROUTES.USER.PROFILE);
//       }
//     },
//     onError: (error: ApiErrorResponse) => {
//       toaster.create({
//         title: error?.response?.data?.message,
//         type: "error",
//       });
//     },
//   });
// };
"use client";

import { orderPost } from "@/api";
import { toaster } from "@/components";
import { ROUTES } from "@/constants";
import { useCheckoutStore } from "@/store/products/checkoutStore";
import { ApiErrorResponse, OrderPostType } from "@/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";

export const useOrderMutation = (selectedPaymentMethod: string) => {
  const router = useRouter();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: OrderPostType) =>
      orderPost({
        items: data.items,
        selectedPaymentMethod,
        referenceCode: data.referenceCode,
        coupon_code: data.coupon_code,
        delivery_location: data.delivery_location,
        delivery_note: data.delivery_note,
        delivery_address: data.delivery_address,
        billing_address: data.billing_address,
        surge_charges: data.surge_charges,
        shipping: data.shipping,
        discount: data.discount,
      }),

    onSuccess: (response) => {
      const order = response?.data?.data;

      toaster.create({
        title: order?.message || "Order placed successfully!",
        type: "success",
      });

      queryClient.invalidateQueries({ queryKey: ["cart-count"] });

      if (selectedPaymentMethod === "Visa / Mastercard") {
        const checkoutData = {
          order_id: order.order_id,
          customer: order.customer,
          currency: order.currency,
          description: order.description,
          returnurl: order.returnurl,
          cancelurl: order.cancelurl,
          amount: order.amount,
        };

        useCheckoutStore.getState().setCheckoutData(checkoutData);
        router.push(ROUTES.USER.CHECKOUT);
      } else {
        router.push(ROUTES.USER.PROFILE);
        queryClient.invalidateQueries({ queryKey: ["order-list"] });
      }
    },

    onError: (error: ApiErrorResponse) => {
      toaster.create({
        title: error?.response?.data?.message || "Order failed",
        type: "error",
      });
    },
  });
};
