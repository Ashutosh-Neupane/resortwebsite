import { postNewAddress } from "@/api";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toaster } from "@/components";

export const useAddAddress = () => {
   const queryClient = useQueryClient();
  return useMutation({
    mutationFn: postNewAddress,
    onSuccess: (response) => {
      queryClient.invalidateQueries({ 
        queryKey: ['user-profile'] 
      });
      toaster.create({
        title: "Address added",
        description: response.data[0]?.address || "",
        type: "success",
        duration: 4000,
      });
    },
  });
};
