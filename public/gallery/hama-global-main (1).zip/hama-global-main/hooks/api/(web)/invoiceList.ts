import { getInvoiceData } from "@/api/queries/products/invoiceList";
import { useQuery } from "@tanstack/react-query";

export const useInvoiceListQuery = () => {
  return useQuery({
    queryKey: ["invoice-list"],
    queryFn: getInvoiceData,
    select: (response) => response?.data.message,
  });
};
